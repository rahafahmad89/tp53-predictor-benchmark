"""
04_pairwise_comparison.py

Step 4: pairwise comparison between tools.

  (a) Discordance matrix: for each pair of tools, % of variants where
      their binary calls disagree, restricted to variants where BOTH
      tools produced a Pathogenic/Benign call (VUS/Missing excluded
      pairwise, not dataset-wide).

  (b) DeLong's test: for each pair of tools, statistical significance
      of the difference between their ROC-AUCs, computed on the shared
      set of variants that have a score from BOTH tools (paired test —
      required, since DeLong assumes the same underlying cases).

DeLong's method (Sun & Xu, 2014 fast implementation) is implemented
directly below — no extra dependency beyond numpy/pandas/scipy.
"""

import pandas as pd
import numpy as np
from scipy import stats
from itertools import combinations

# ---------------------------------------------------------------------------
# CONFIG — same as 03_benchmark_metrics.py
# ---------------------------------------------------------------------------

FILES = {
    "germline": "germline_classified.csv",
    "somatic": "somatic_classified.csv",
}

LABEL_COL = "Binary_label"
PATHOGENIC_LABELS = {"Pathogenic", "pathogenic"}
BENIGN_LABELS = {"Benign", "benign"}

TOOL_CONFIG = {
    "SIFT":          {"score_col": "SIFT_score",          "higher_is_pathogenic": False, "call_col": "SIFT_call"},
    "REVEL":         {"score_col": "REVEL_score",         "higher_is_pathogenic": True,  "call_col": "REVEL_call"},
    "CADD":          {"score_col": "CADD_score",          "higher_is_pathogenic": True,  "call_col": "CADD_call"},
    "ClinPred":      {"score_col": "ClinPred_score",      "higher_is_pathogenic": True,  "call_col": "ClinPred_call"},
    "MetaLR":        {"score_col": "MetaLR_score",        "higher_is_pathogenic": True,  "call_col": "MetaLR_call"},
    "MetaRNN":       {"score_col": "MetaRNN_score",       "higher_is_pathogenic": True,  "call_col": "MetaRNN_call"},
    "MetaSVM":       {"score_col": "MetaSVM_score",       "higher_is_pathogenic": True,  "call_col": "MetaSVM_call"},
    "MVP":           {"score_col": "MVP_score",           "higher_is_pathogenic": True,  "call_col": "MVP_call"},
    "Provean":       {"score_col": "PROVEAN_score",       "higher_is_pathogenic": False, "call_col": "Provean_call"},
    "DANN":          {"score_col": "DANN_score",          "higher_is_pathogenic": True,  "call_col": "DANN_call"},
    # REVISION (item 5)
    "PolyPhen2_HDIV": {"score_col": "Polyphen2_HDIV_score", "higher_is_pathogenic": True,  "call_col": "PolyPhen2_HDIV_call"},
    "PolyPhen2_HVAR": {"score_col": "Polyphen2_HVAR_score", "higher_is_pathogenic": True,  "call_col": "PolyPhen2_HVAR_call"},
    "BayesDel":       {"score_col": "BayesDel_noAF_score",  "higher_is_pathogenic": True,  "call_col": "BayesDel_call",       "has_vus": False},
    "AlphaMissense": {"score_col": "AlphaMissense_score", "higher_is_pathogenic": True,  "call_col": "AlphaMissense_call"},
    "EVE":           {"score_col": "EVE_score",           "higher_is_pathogenic": True,  "call_col": "EVE_call"},
}

MIN_PAIRED_N = 10  # minimum shared variants required to run a pairwise test

# ---------------------------------------------------------------------------
# DeLong's test implementation (Sun & Xu, 2014 fast O(n log n) version)
# ---------------------------------------------------------------------------


def _compute_midrank(x):
    J = np.argsort(x)
    Z = x[J]
    N = len(x)
    T = np.zeros(N, dtype=float)
    i = 0
    while i < N:
        j = i
        while j < N and Z[j] == Z[i]:
            j += 1
        T[i:j] = 0.5 * (i + j - 1) + 1
        i = j
    T2 = np.empty(N, dtype=float)
    T2[J] = T
    return T2


def _fast_delong(predictions_sorted_transposed, label_1_count):
    m = label_1_count
    n = predictions_sorted_transposed.shape[1] - m
    positive_examples = predictions_sorted_transposed[:, :m]
    negative_examples = predictions_sorted_transposed[:, m:]
    k = predictions_sorted_transposed.shape[0]

    tx = np.empty([k, m], dtype=float)
    ty = np.empty([k, n], dtype=float)
    tz = np.empty([k, m + n], dtype=float)
    for r in range(k):
        tx[r, :] = _compute_midrank(positive_examples[r, :])
        ty[r, :] = _compute_midrank(negative_examples[r, :])
        tz[r, :] = _compute_midrank(predictions_sorted_transposed[r, :])

    aucs = tz[:, :m].sum(axis=1) / (m * n) - (m + 1.0) / (2.0 * n)

    v01 = (tz[:, :m] - tx[:, :]) / n
    v10 = 1.0 - (tz[:, m:] - ty[:, :]) / m

    sx = np.cov(v01)
    sy = np.cov(v10)
    delongcov = sx / m + sy / n
    return aucs, delongcov


def delong_roc_test(y_true, score_a, score_b):
    """
    Paired DeLong test for two ROC-AUCs on the same set of cases.
    y_true: 0/1 array. score_a/score_b: higher = more positive class,
    already oriented (caller must flip inverted-direction tools first).
    Returns (auc_a, auc_b, z_stat, p_value).
    """
    order = np.argsort(-y_true)
    y_true_sorted = y_true[order]
    label_1_count = int(np.sum(y_true_sorted))

    preds = np.vstack([score_a[order], score_b[order]])
    aucs, delongcov = _fast_delong(preds, label_1_count)

    auc_diff = aucs[0] - aucs[1]
    var = delongcov[0, 0] + delongcov[1, 1] - 2 * delongcov[0, 1]
    if var <= 0:
        return aucs[0], aucs[1], np.nan, np.nan  # degenerate, can't test
    z = auc_diff / np.sqrt(var)
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    return aucs[0], aucs[1], z, p


# ---------------------------------------------------------------------------


def binarize_labels(df, label_col):
    is_path = df[label_col].isin(PATHOGENIC_LABELS)
    is_ben = df[label_col].isin(BENIGN_LABELS)
    y = pd.Series(np.nan, index=df.index)
    y[is_path] = 1
    y[is_ben] = 0
    return y


def oriented_score(df, tool):
    cfg = TOOL_CONFIG[tool]
    s = df[cfg["score_col"]].astype(float)
    return s if cfg["higher_is_pathogenic"] else -s


def discordance_matrix(df):
    tools = list(TOOL_CONFIG.keys())
    mat = pd.DataFrame(index=tools, columns=tools, dtype=float)
    n_mat = pd.DataFrame(index=tools, columns=tools, dtype=int)

    for t1, t2 in combinations(tools, 2):
        c1 = df[TOOL_CONFIG[t1]["call_col"]]
        c2 = df[TOOL_CONFIG[t2]["call_col"]]
        mask = c1.isin(["Pathogenic", "Benign"]) & c2.isin(["Pathogenic", "Benign"])
        n = mask.sum()
        if n == 0:
            disc = np.nan
        else:
            disc = 100 * (c1[mask] != c2[mask]).sum() / n
        mat.loc[t1, t2] = disc
        mat.loc[t2, t1] = disc
        n_mat.loc[t1, t2] = n
        n_mat.loc[t2, t1] = n

    for t in tools:                      # REVISION: works on all pandas versions
        mat.loc[t, t] = 0.0
    return mat, n_mat


def pairwise_delong(df, y_true):
    tools = list(TOOL_CONFIG.keys())
    rows = []

    for t1, t2 in combinations(tools, 2):
        s1 = oriented_score(df, t1)
        s2 = oriented_score(df, t2)
        mask = s1.notna() & s2.notna() & y_true.notna()
        n = mask.sum()

        if n < MIN_PAIRED_N or y_true[mask].nunique() < 2:
            rows.append({"tool_a": t1, "tool_b": t2, "n_paired": int(n),
                         "auc_a": None, "auc_b": None, "z": None, "p": None,
                         "note": "insufficient paired data"})
            continue

        y = y_true[mask].to_numpy(dtype=float)
        a = s1[mask].to_numpy(dtype=float)
        b = s2[mask].to_numpy(dtype=float)

        auc_a, auc_b, z, p = delong_roc_test(y, a, b)
        rows.append({
            "tool_a": t1, "tool_b": t2, "n_paired": int(n),
            "auc_a": round(auc_a, 4), "auc_b": round(auc_b, 4),
            "z": round(z, 3) if not np.isnan(z) else None,
            "p": round(p, 5) if not np.isnan(p) else None,
            "note": "significant (p<0.05)" if (not np.isnan(p) and p < 0.05) else "",
        })

    return pd.DataFrame(rows)


def main():
    for name, path in FILES.items():
        print("=" * 70)
        print(f"DATASET: {name} ({path})")
        print("=" * 70)

        df = pd.read_csv(path)
        y_true = binarize_labels(df, LABEL_COL)

        print("\nComputing discordance matrix...")
        disc_mat, disc_n = discordance_matrix(df)
        disc_mat.to_csv(f"discordance_matrix_{name}.csv")
        disc_n.to_csv(f"discordance_n_{name}.csv")
        print(f"Saved: discordance_matrix_{name}.csv, discordance_n_{name}.csv")

        print("\nTop 10 most discordant tool pairs:")
        pairs = []
        tools = list(TOOL_CONFIG.keys())
        for t1, t2 in combinations(tools, 2):
            pairs.append((t1, t2, disc_mat.loc[t1, t2]))
        pairs_df = pd.DataFrame(pairs, columns=["tool_a", "tool_b", "discordance_pct"])
        pairs_df = pairs_df.sort_values("discordance_pct", ascending=False)
        print(pairs_df.head(10).to_string(index=False))

        print("\nComputing DeLong pairwise AUC tests (this may take a moment)...")
        delong_df = pairwise_delong(df, y_true)
        # REVISION (item 23): Benjamini-Hochberg FDR across all valid comparisons in this dataset
        from statsmodels.stats.multitest import multipletests
        valid = delong_df["p"].notna()
        delong_df["p_BH"] = np.nan
        delong_df.loc[valid, "p_BH"] = multipletests(delong_df.loc[valid, "p"].astype(float), method="fdr_bh")[1]
        delong_df["significant_BH"] = delong_df["p_BH"] < 0.05
        print(f"BH-FDR: {int(delong_df['significant_BH'].sum())} of {int((delong_df['p'] < 0.05).sum())} "
              f"nominally significant comparisons remain significant (of {int(valid.sum())} valid)")
        delong_df.to_csv(f"delong_pairwise_{name}.csv", index=False)
        print(f"Saved: delong_pairwise_{name}.csv")

        n_sig = (delong_df["note"] == "significant (p<0.05)").sum()
        n_valid = delong_df["p"].notna().sum()
        print(f"\n{n_sig} / {n_valid} valid pairwise comparisons show a "
              f"statistically significant AUC difference (p<0.05)")

        print("\nNon-significant pairs (AUC differences NOT statistically "
              "distinguishable — useful to know which tools are "
              "interchangeable in performance):")
        non_sig = delong_df[(delong_df["p"].notna()) & (delong_df["p"] >= 0.05)]
        print(non_sig[["tool_a", "tool_b", "auc_a", "auc_b", "p"]].to_string(index=False))


if __name__ == "__main__":
    main()
