"""
08_residue_mapping_check.py

Purpose: before building MD input files, confirm that:
  1. The residue numbering in each candidate PDB structure matches the
     canonical UniProt TP53 sequence at positions 110 and 262 (i.e. no
     numbering offset between the construct used for crystallography and
     the isoform your Unified_ID/HGVSp calls are based on).
  2. Both target residues actually have resolved coordinates in that
     chain (loops can be disordered/missing from crystal structures,
     which would silently break a mutagenesis step downstream if not
     caught here first).

This downloads:
  - The canonical UniProt P04637 (human TP53) sequence directly from
    UniProt, rather than relying on any hardcoded sequence — a wrong
    hardcoded reference here would silently corrupt every downstream
    numbering decision, so it's fetched fresh every run.
  - Each candidate PDB structure from RCSB.

Requires: biopython, requests (pip install biopython requests --break-system-packages)

Run this on your local machine (needs internet access to rcsb.org and
uniprot.org).
"""

import requests
from Bio.PDB import PDBParser, PPBuilder
from Bio.Data.IUPACData import protein_letters_3to1_extended
import warnings
warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------

UNIPROT_ID = "P04637"  # human TP53

CANDIDATE_STRUCTURES = [
    # (pdb_id, chain_id) — chain A is usually the p53 protein chain, but
    # verify against the PDB entry page since some are asymmetric units
    # with multiple copies (A/B/C/D) and DNA/peptide chains mixed in.
    ("1TUP", "A"),
    ("1TSR", "A"),
    ("2XWR", "A"),
    ("2OCJ", "A"),
]

TARGET_POSITIONS = {
    110: "R",  # R110L variant — expect Arg (R) at position 110
    262: "G",  # G262S variant — expect Gly (G) at position 262
}

THREE_TO_ONE = {k.upper(): v for k, v in protein_letters_3to1_extended.items()}

# ---------------------------------------------------------------------------


def fetch_uniprot_sequence(uniprot_id):
    url = f"https://rest.uniprot.org/uniprotkb/{uniprot_id}.fasta"
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    lines = r.text.strip().split("\n")
    seq = "".join(lines[1:])  # skip header line
    return seq


def fetch_pdb_file(pdb_id, out_path):
    url = f"https://files.rcsb.org/download/{pdb_id}.pdb"
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    with open(out_path, "w") as f:
        f.write(r.text)


def get_pdb_residue_map(pdb_path, chain_id):
    """Returns {author_residue_number: one_letter_aa} for resolved residues only."""
    parser = PDBParser(QUIET=True)
    structure = parser.get_structure("struct", pdb_path)
    model = structure[0]
    if chain_id not in model:
        return None, f"Chain {chain_id} not found — available chains: {[c.id for c in model]}"

    chain = model[chain_id]
    res_map = {}
    for residue in chain:
        if residue.id[0] != " ":
            continue  # skip heteroatoms/waters
        resname = residue.get_resname().upper()
        if resname not in THREE_TO_ONE:
            continue
        res_map[residue.id[1]] = THREE_TO_ONE[resname]
    return res_map, None


def main():
    print("Fetching canonical UniProt sequence...")
    uniprot_seq = fetch_uniprot_sequence(UNIPROT_ID)
    print(f"  UniProt {UNIPROT_ID} length: {len(uniprot_seq)} residues")

    print("\nUniProt reference at target positions:")
    for pos, expected_aa in TARGET_POSITIONS.items():
        actual = uniprot_seq[pos - 1]  # 1-indexed
        match = "OK" if actual == expected_aa else "MISMATCH — check numbering assumption!"
        print(f"  Position {pos}: UniProt has '{actual}', expected '{expected_aa}' -> {match}")

    print("\n" + "=" * 70)
    print("Checking candidate PDB structures")
    print("=" * 70)

    results = []
    for pdb_id, chain_id in CANDIDATE_STRUCTURES:
        print(f"\n--- {pdb_id} chain {chain_id} ---")
        pdb_path = f"/tmp/{pdb_id}.pdb"
        try:
            fetch_pdb_file(pdb_id, pdb_path)
        except Exception as e:
            print(f"  [ERROR] could not download {pdb_id}: {e}")
            continue

        res_map, err = get_pdb_residue_map(pdb_path, chain_id)
        if err:
            print(f"  [ERROR] {err}")
            continue

        min_res = min(res_map.keys()) if res_map else None
        max_res = max(res_map.keys()) if res_map else None
        print(f"  Resolved residue range in chain {chain_id}: {min_res}-{max_res} "
              f"({len(res_map)} residues with coordinates)")

        row = {"pdb_id": pdb_id, "chain": chain_id, "res_range": f"{min_res}-{max_res}"}
        for pos, expected_aa in TARGET_POSITIONS.items():
            if pos not in res_map:
                status = "MISSING (disordered/not in construct)"
            elif res_map[pos] == expected_aa:
                status = f"OK — resolved as {res_map[pos]}"
            else:
                status = f"MISMATCH — PDB has {res_map[pos]}, expected {expected_aa}"
            print(f"    Position {pos} (expect {expected_aa}): {status}")
            row[f"pos_{pos}_status"] = status

        results.append(row)

    print("\n" + "=" * 70)
    print("SUMMARY — which structures are usable for both target residues")
    print("=" * 70)
    for row in results:
        ok_110 = "OK" in row.get("pos_110_status", "")
        ok_262 = "OK" in row.get("pos_262_status", "")
        verdict = "USABLE FOR BOTH" if (ok_110 and ok_262) else \
            ("usable for 262 only" if ok_262 else
             ("usable for 110 only" if ok_110 else "not usable for either"))
        print(f"  {row['pdb_id']} chain {row['chain']} (range {row['res_range']}): {verdict}")


if __name__ == "__main__":
    main()
