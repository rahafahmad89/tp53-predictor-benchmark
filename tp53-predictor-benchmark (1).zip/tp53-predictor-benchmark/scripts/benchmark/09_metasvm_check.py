"""
09_metasvm_check.py  -  Revision item 1: is MetaSVM's DBD AUC (0.266) a parsing error?

Runs on germline_benchmark_final.csv / somatic_benchmark_final_confident.csv (the files 02 reads).
If germline_benchmark_final_v2.csv exists (made by merge_new_vep_scores.py), it also compares
MetaSVM in your benchmark file with MetaSVM from the NEW VEP run, variant by variant ([C]).

Writes metasvm_check_report.txt
"""
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

import revision_utils as R

FINAL = {"germline": "germline_benchmark_final.csv", "somatic": "somatic_benchmark_final_confident.csv"}
OTHERS = ["MetaLR_score", "REVEL_score", "CADD_score", "MetaRNN_score", "ClinPred_score",
          "AlphaMissense_score", "MVP_score", "DANN_score"]
out = []


def say(s=""):
    print(s); out.append(s)


for name, f in FINAL.items():
    d = pd.read_csv(R.DATA / f)
    d["pos"] = pd.to_numeric(d["Protein_position"], errors="coerce")
    d["region"] = np.where(d["pos"].between(*R.DBD_RANGE), "DBD", "non-DBD")
    d["y"] = d["Binary_label"].map({"Pathogenic": 1, "Benign": 0})
    s = d["MetaSVM_score"]
    say(f"===== {name}: {s.notna().sum()} variants with a MetaSVM score =====")
    say(f"[A] range {s.min():.3f} to {s.max():.3f}  (raw MetaSVM; a rankscore would sit inside 0-1)")
    ok = s.notna() & d["MetaSVM_pred"].isin(["D", "T"])
    agree = ((s[ok] > 0) == (d.loc[ok, "MetaSVM_pred"] == "D")).mean()
    say(f"[A] MetaSVM_pred agrees with sign of MetaSVM_score in {agree:.1%} of variants "
        f"(D if score > 0). 100% = score and prediction come from the same dbNSFP row.")
    for reg in ["DBD", "non-DBD"]:
        g = d[d.region == reg]
        say(f"[B] {reg}: n = {g['MetaSVM_score'].notna().sum()}, MetaSVM range "
            f"{g['MetaSVM_score'].min():.3f} to {g['MetaSVM_score'].max():.3f}; "
            f"AUC = {R.auc(*g.dropna(subset=['MetaSVM_score'])[['y', 'MetaSVM_score']].values.T):.3f}")
        for o in OTHERS:
            m = g.dropna(subset=["MetaSVM_score", o])
            rho = spearmanr(m["MetaSVM_score"], m[o]).statistic
            say(f"      Spearman MetaSVM vs {o.replace('_score', ''):14s} {rho:+.2f}")
    say()

v2 = R.DATA / "germline_benchmark_final_v2.csv"
if v2.exists() and "MetaSVM_score_newVEP" in pd.read_csv(v2, nrows=1).columns:
    m = pd.read_csv(v2)[["Unified_ID", "MetaSVM_score", "MetaSVM_score_newVEP"]].dropna()
    same = np.isclose(m["MetaSVM_score"], m["MetaSVM_score_newVEP"], atol=1e-4)
    say(f"[C] New VEP run vs original benchmark file: {same.sum()}/{len(m)} identical MetaSVM scores")
    if (~same).any():
        m[~same].to_csv("metasvm_old_vs_new_mismatches.csv", index=False)
        say("    differences written to metasvm_old_vs_new_mismatches.csv")
else:
    say("[C] skipped: run merge_new_vep_scores.py first to compare with a fresh VEP run")

say("""
HOW TO READ THIS
- If [A] is 100% and the range is the raw-score range: your scripts read MetaSVM correctly.
- A parsing or row-alignment error gives Spearman values near 0 against every other tool.
  A consistent, strong NEGATIVE correlation with every other tool inside the DBD, together with a
  compressed score range there, means the inverted ranking is in the MetaSVM scores themselves.
""")
open("metasvm_check_report.txt", "w").write("\n".join(out))
print("Saved: metasvm_check_report.txt")
