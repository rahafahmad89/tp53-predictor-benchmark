"""
10_bootstrap_ci.py  -  Revision item 4: uncertainty for Tables 1-3.

Reads germline_classified.csv and somatic_classified.csv (written by 02), the tool lists in 03 and 05,
and recomputes the germline MCC-max thresholds exactly as 05 does.
Run AFTER 02, 03 and 05.   Runtime: a few minutes.

Writes
  table1_auc_ci.csv            ROC-AUC (95% CI), PR-AUC (95% CI), and default-threshold
                               sensitivity / specificity / MCC (95% CI), per tool and dataset
  table2_recalibration_ci.csv  germline-derived MCC threshold, and its performance:
                               germline in-sample (apparent), optimism-corrected, 5x50 cross-validated,
                               and somatic (the threshold fixed, somatic resampled)
  table3_threshold_ci.csv      germline- and somatic-derived thresholds with 95% CI, and what the
                               somatic threshold does to germline specificity / sensitivity (scale-free)
Bootstrap: 2000 resamples, stratified by class, fixed seed.
"""
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score
from sklearn.model_selection import RepeatedStratifiedKFold

import revision_utils as R

rng = np.random.default_rng(R.SEED)
B = R.N_BOOT
data = {k: R.load(k) for k in ("germline", "somatic")}

# ---------------------------------------------------------------- Table 1
rows = []
for name, d in data.items():
    for tool, cfg in R.TOOLS.items():
        s = R.oriented(d, tool); m = s.notna() & d.y.notna()
        y, sc = d.y[m].to_numpy(int), s[m].to_numpy(float)
        a, ap = R.auc(y, sc), average_precision_score(y, sc)
        ba, bp = [], []
        for _ in range(B):
            i = R.boot_idx(y, rng); ba.append(R.auc(y[i], sc[i])); bp.append(average_precision_score(y[i], sc[i]))
        row = {"tool": tool, "dataset": name, "n_scored": len(y),
               "AUC": round(a, 4), "AUC_95CI": R.fmt(a, *R.ci(ba)), "PRAUC_95CI": R.fmt(ap, *R.ci(bp))}
        calls = d[cfg["call_col"]]; mc = calls.isin(["Pathogenic", "Benign"]) & d.y.notna()
        yc, pc = d.y[mc].to_numpy(int), (calls[mc] == "Pathogenic").to_numpy(int)
        est = R.metrics(yc, pc)
        bs = [R.metrics(yc[i], pc[i]) for i in (R.boot_idx(yc, rng) for _ in range(B))]
        row["n_called_default"] = len(yc)
        for k in ["sensitivity", "specificity", "mcc"]:
            row[f"default_{k}_95CI"] = R.fmt(est[k], *R.ci([b[k] for b in bs]))
        rows.append(row)
t1 = pd.DataFrame(rows)
t1.to_csv("table1_auc_ci.csv", index=False)
print(t1[["tool", "dataset", "n_scored", "AUC_95CI", "default_specificity_95CI"]].to_string(index=False))

# ---------------------------------------------------------------- Table 2 and 3
G, S = data["germline"], data["somatic"]
thr_g = R.germline_mcc_thresholds()
rskf = RepeatedStratifiedKFold(n_splits=5, n_repeats=50, random_state=R.SEED)
rows2, rows3 = [], []
for tool, cfg in R.RECAL_TOOLS.items():
    sg = R.oriented(G, tool, R.RECAL_TOOLS); mg = sg.notna() & G.y.notna()
    ss = R.oriented(S, tool, R.RECAL_TOOLS); ms = ss.notna() & S.y.notna()
    yg, xg = G.y[mg].to_numpy(int), sg[mg].to_numpy(float)
    ys, xs = S.y[ms].to_numpy(int), ss[ms].to_numpy(float)
    t_or = thr_g[tool] if cfg["higher_is_pathogenic"] else -thr_g[tool]      # oriented threshold
    app = R.metrics(yg, xg >= t_or); oos = R.metrics(ys, xs >= t_or)
    b_app, b_oos, opt, b_tg, b_ts = [], [], [], [], []
    for _ in range(B):
        i = R.boot_idx(yg, rng); j = R.boot_idx(ys, rng)
        b_app.append(R.metrics(yg[i], xg[i] >= t_or)); b_oos.append(R.metrics(ys[j], xs[j] >= t_or))
        tb = R.mcc_threshold(yg[i], xg[i])
        mb, mo = R.metrics(yg[i], xg[i] >= tb), R.metrics(yg, xg >= tb)
        opt.append({k: mb[k] - mo[k] for k in mb})
        b_tg.append(tb); b_ts.append(R.mcc_threshold(ys[j], xs[j]))
    # cross-validation within germline
    cv = []
    pred = np.zeros_like(yg)
    for f, (tr, te) in enumerate(rskf.split(xg, yg)):
        pred[te] = xg[te] >= R.mcc_threshold(yg[tr], xg[tr])
        if (f + 1) % 5 == 0:
            cv.append(R.metrics(yg, pred))
    r = {"tool": tool, "germline_MCC_threshold": round(thr_g[tool], 4)}
    for k in ["specificity", "sensitivity", "mcc"]:
        r[f"{k}_germline_insample"] = R.fmt(app[k], *R.ci([b[k] for b in b_app]))
        r[f"{k}_germline_optimism_corrected"] = round(app[k] - np.mean([o[k] for o in opt]), 3)
        v = [c[k] for c in cv]
        r[f"{k}_germline_CV5x50_mean_(2.5-97.5pct_of_repeats)"] = R.fmt(np.mean(v), *R.ci(v))
        r[f"{k}_somatic"] = R.fmt(oos[k], *R.ci([b[k] for b in b_oos]))
    rows2.append(r)
    sign = 1 if cfg["higher_is_pathogenic"] else -1
    t_s = R.mcc_threshold(ys, xs)
    at_s = R.metrics(yg, xg >= t_s)
    rows3.append({"tool": tool,
                  "germline_thr_95CI": R.fmt(sign * t_or, *sorted(sign * np.array(R.ci(b_tg))), nd=4),
                  "somatic_thr_95CI": R.fmt(sign * t_s, *sorted(sign * np.array(R.ci(b_ts))), nd=4),
                  "abs_delta": round(abs(t_or - t_s), 4),
                  "germline_spec_change_pp_if_somatic_thr": round(100 * (at_s["specificity"] - app["specificity"]), 1),
                  "germline_sens_change_pp_if_somatic_thr": round(100 * (at_s["sensitivity"] - app["sensitivity"]), 1)})
    print(f"  {tool} done")
t2 = pd.DataFrame(rows2); t2.to_csv("table2_recalibration_ci.csv", index=False)
t3 = pd.DataFrame(rows3); t3.to_csv("table3_threshold_ci.csv", index=False)
print(t2[["tool", "specificity_germline_insample", "specificity_germline_CV5x50_mean_(2.5-97.5pct_of_repeats)", "specificity_somatic"]].to_string(index=False))
print(t3.to_string(index=False))
print("Saved: table1_auc_ci.csv, table2_recalibration_ci.csv, table3_threshold_ci.csv")
