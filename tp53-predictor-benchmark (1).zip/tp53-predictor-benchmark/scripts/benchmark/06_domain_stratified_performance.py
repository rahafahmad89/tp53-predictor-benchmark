"""
06_domain_stratified_performance.py

Step 6: check whether tool performance varies by TP53 protein domain —
same logic that surfaced the PolyPhen coverage cutoff, extended to all
scored tools. If a tool's accuracy drops specifically in the DNA-binding
domain (where most pathogenic variants cluster and where structure is
richest), that's directly relevant to both the discordance narrative and
MD candidate selection.

Domain boundaries (UniProt P04637, standard TP53 domain map):
    Transactivation domain 1 (TAD1):   1-42
    Transactivation domain 2 (TAD2):   43-63
    Proline-rich domain (PRD):         64-93
    DNA-binding domain (DBD):          94-312
    Nuclear localization signal (NLS): 313-322
    Tetramerization domain (OD/TET):   323-356
    C-terminal regulatory domain (CTD):357-393

VERIFY these boundaries against your preferred reference before
finalizing for the paper — different sources draw the PRD/DBD and
OD/CTD edges slightly differently (e.g. some put DBD start at 102 not
94). Your own PolyPhen finding used ~94/95 as the cutoff, so that
boundary is used here to stay consistent with what you've already
validated.

Given TP53 pathogenic variants concentrate heavily in the DBD, this
script first prints the n per domain so you can see where there's
enough data for a fair comparison before trusting any per-domain AUC.
"""

import re
import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score

# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------

FILES = {
    "germline": "germline_classified.csv",
    "somatic": "somatic_classified.csv",
}

LABEL_COL = "Binary_label"
PATHOGENIC_LABELS = {"Pathogenic", "pathogenic"}
BENIGN_LABELS = {"Benign", "benign"}

PROTEIN_POS_COL = "Protein_position"

DOMAINS = [
    ("TAD1", 1, 42),
    ("TAD2", 43, 63),
    ("PRD", 64, 93),
    ("DBD", 94, 312),
    ("NLS", 313, 322),
    ("OD_TET", 323, 356),
    ("CTD", 357, 393),
]

# Collapsed 2-way view (DBD is the one with structural + functional weight)
DBD_RANGE = (94, 312)

TOOL_SCORE_COLS = {
    "SIFT": ("SIFT_score", False),
    "REVEL": ("REVEL_score", True),
    "CADD": ("CADD_score", True),
    "ClinPred": ("ClinPred_score", True),
    "MetaLR": ("MetaLR_score", True),
    "MetaRNN": ("MetaRNN_score", True),
    "MetaSVM": ("MetaSVM_score", True),
    "MVP": ("MVP_score", True),
    "Provean": ("PROVEAN_score", False),
    "DANN": ("DANN_score", True),
    "PolyPhen2_HDIV": ("Polyphen2_HDIV_score", True),   # REVISION (item 5)
    "PolyPhen2_HVAR": ("Polyphen2_HVAR_score", True),
    "BayesDel": ("BayesDel_noAF_score", True),
    "AlphaMissense": ("AlphaMissense_score", True),
    "EVE": ("EVE_score", True),
}

MIN_N_PER_CLASS = 8  # minimum count of BOTH pathogenic and benign to trust an AUC

# ---------------------------------------------------------------------------


def parse_position(val):
    if pd.isna(val):
        return np.nan
    m = re.search(r"\d+", str(val))
    return int(m.group()) if m else np.nan


def binarize_labels(df, label_col):
    is_path = df[label_col].isin(PATHOGENIC_LABELS)
    is_ben = df[label_col].isin(BENIGN_LABELS)
    y = pd.Series(np.nan, index=df.index)
    y[is_path] = 1
    y[is_ben] = 0
    return y


def assign_domain(pos):
    if pd.isna(pos):
        return "Unknown"
    for name, lo, hi in DOMAINS:
        if lo <= pos <= hi:
            return name
    return "OutOfRange"


def compute_auc(y, scores, higher_is_pathogenic):
    mask = scores.notna() & y.notna()
    n = mask.sum()
    if n < MIN_N_PER_CLASS * 2:
        return None, None, int(n), int((y[mask] == 1).sum()), int((y[mask] == 0).sum())
    yy = y[mask].astype(int)
    if yy.nunique() < 2 or yy.sum() < MIN_N_PER_CLASS or (len(yy) - yy.sum()) < MIN_N_PER_CLASS:
        return None, None, int(n), int(yy.sum()), int((yy == 0).sum())
    s = scores[mask].astype(float)
    if not higher_is_pathogenic:
        s = -s
    return round(roc_auc_score(yy, s), 4), round(average_precision_score(yy, s), 4), \
        int(n), int(yy.sum()), int((yy == 0).sum())


def main():
    for name, path in FILES.items():
        print("=" * 70)
        print(f"DATASET: {name} ({path})")
        print("=" * 70)

        df = pd.read_csv(path)
        y = binarize_labels(df, LABEL_COL)
        df["_position"] = df[PROTEIN_POS_COL].apply(parse_position)
        df["_domain"] = df["_position"].apply(assign_domain)

        print("\nVariant counts by domain (ground-truth labeled only):")
        labeled = df[y.notna()].copy()
        labeled["_label"] = y[y.notna()]
        domain_counts = labeled.groupby("_domain")["_label"].agg(
            n_total="count", n_pathogenic="sum"
        )
        domain_counts["n_benign"] = domain_counts["n_total"] - domain_counts["n_pathogenic"]
        print(domain_counts.to_string())

        # 2-way DBD vs non-DBD, this is the comparison with real statistical power
        is_dbd = (df["_position"] >= DBD_RANGE[0]) & (df["_position"] <= DBD_RANGE[1])
        print(f"\nDBD ({DBD_RANGE[0]}-{DBD_RANGE[1]}) vs non-DBD split "
              f"(ground-truth labeled only):")
        for region_name, region_mask in [("DBD", is_dbd), ("non-DBD", ~is_dbd)]:
            region_y = y[region_mask & y.notna()]
            print(f"  {region_name}: n={len(region_y)}, "
                  f"Pathogenic={int((region_y==1).sum())}, "
                  f"Benign={int((region_y==0).sum())}")

        rows = []
        for tool, (score_col, hip) in TOOL_SCORE_COLS.items():
            if score_col not in df.columns:
                continue
            for region_name, region_mask in [("DBD", is_dbd), ("non-DBD", ~is_dbd),
                                               ("ALL", pd.Series(True, index=df.index))]:
                sub_y = y[region_mask]
                sub_scores = df.loc[region_mask, score_col]
                roc_auc, pr_auc, n, n_path, n_ben = compute_auc(sub_y, sub_scores, hip)
                rows.append({
                    "tool": tool, "region": region_name,
                    "n_used": n, "n_pathogenic": n_path, "n_benign": n_ben,
                    "roc_auc": roc_auc, "pr_auc": pr_auc,
                })

        result = pd.DataFrame(rows)
        out_path = f"domain_stratified_{name}.csv"
        result.to_csv(out_path, index=False)

        print("\nROC-AUC by domain region (blank = insufficient n per class):")
        pivot = result.pivot(index="tool", columns="region", values="roc_auc")
        cols_order = [c for c in ["DBD", "non-DBD", "ALL"] if c in pivot.columns]
        print(pivot[cols_order].to_string())

        print(f"\nSaved: {out_path}")


if __name__ == "__main__":
    main()
