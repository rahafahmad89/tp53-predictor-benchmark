"""
build_final_recommended_thresholds.py

Builds final_recommended_thresholds.csv reproducibly from
suggested_thresholds_summary.csv (output of 05_suggest_thresholds.py).

WHY THIS SCRIPT EXISTS
-----------------------
The original final_recommended_thresholds.csv was built by hand and
silently mixed an IN-SAMPLE germline number with an OUT-OF-SAMPLE
somatic number in adjacent columns (recalibrated_spec_germline_insample,
recalibrated_spec_somatic_outsample), with no script generating it and
no label distinguishing the two. That's an easy, avoidable target for a
reviewer: it looks like circularity even though the underlying analysis
(05_suggest_thresholds.py) already does two-way, out-of-sample
validation correctly.

This script fixes that by:
  1. Making the derivation fully reproducible (run this, get the file --
     no manual CSV editing).
  2. Explicitly labeling every specificity/MCC value as INSAMPLE or
     OUTSAMPLE, and by which dataset it was derived on vs evaluated on.
  3. Keeping BOTH directions (germline-derived and somatic-derived) in
     full, rather than picking one direction per tool by hand.

WHICH NUMBERS TO CITE IN THE MANUSCRIPT
-----------------------------------------
Use the *_OUTSAMPLE_* columns as your headline generalization claim
(e.g., "germline_derived_spec_OUTSAMPLE_somatic"). The *_INSAMPLE_*
columns are for internal transparency/comparison only -- do not report
them as evidence the recalibrated threshold generalizes, since by
definition they were evaluated on the same data used to derive them.

If germline-derived and somatic-derived out-of-sample numbers are
close to each other and close to their respective in-sample numbers
(as seen for SIFT, CADD, ClinPred in this dataset), that is itself
evidence against overfitting and is worth stating explicitly in the
manuscript's methods/results.
"""

import pandas as pd

IN_PATH = "suggested_thresholds_summary.csv"
OUT_PATH = "final_recommended_thresholds_v2.csv"


def main():
    df = pd.read_csv(IN_PATH)

    rows = []
    for _, r in df.iterrows():
        row = {
            "tool": r["tool"],
            "published_threshold": r.get("published_threshold"),
            "published_note": r.get("published_note"),
        }

        # published-threshold baseline (both tracks, if available)
        row["published_spec_germline"] = r.get("published_germline_specificity")
        row["published_spec_somatic"] = r.get("published_somatic_specificity")
        row["published_mcc_germline"] = r.get("published_germline_mcc")
        row["published_mcc_somatic"] = r.get("published_somatic_mcc")

        # --- germline-derived threshold ---
        row["germline_derived_youden_threshold"] = r.get("germlineDiscovery_youden_threshold")
        row["germline_derived_mcc_threshold"] = r.get("germlineDiscovery_mcc_threshold")

        # in-sample (germline evaluated on germline) -- NOT the headline number
        row["germline_derived_spec_INSAMPLE_germline"] = r.get("germlineDiscovery_youden_insample_specificity")
        row["germline_derived_mcc_INSAMPLE_germline"] = r.get("germlineDiscovery_youden_insample_mcc")

        # out-of-sample (germline-derived, evaluated on somatic) -- HEADLINE number
        row["germline_derived_spec_OUTSAMPLE_somatic"] = r.get("germlineDiscovery_youden_outsample_specificity")
        row["germline_derived_mcc_OUTSAMPLE_somatic"] = r.get("germlineDiscovery_youden_outsample_mcc")

        # --- somatic-derived threshold (mirror direction) ---
        row["somatic_derived_youden_threshold"] = r.get("somaticDiscovery_youden_threshold")
        row["somatic_derived_mcc_threshold"] = r.get("somaticDiscovery_mcc_threshold")

        row["somatic_derived_spec_INSAMPLE_somatic"] = r.get("somaticDiscovery_youden_insample_specificity")
        row["somatic_derived_mcc_INSAMPLE_somatic"] = r.get("somaticDiscovery_youden_insample_mcc")

        row["somatic_derived_spec_OUTSAMPLE_germline"] = r.get("somaticDiscovery_youden_outsample_specificity")
        row["somatic_derived_mcc_OUTSAMPLE_germline"] = r.get("somaticDiscovery_youden_outsample_mcc")

        # stability metric (already computed upstream in script 05)
        row["youden_threshold_stability_abs_diff"] = r.get("youden_threshold_stability_abs_diff")
        row["mcc_threshold_stability_abs_diff"] = r.get("mcc_threshold_stability_abs_diff")

        rows.append(row)

    out = pd.DataFrame(rows)
    out.to_csv(OUT_PATH, index=False)
    print(f"Saved {OUT_PATH} with {len(out)} tools.")
    print("\nColumns kept -- note explicit INSAMPLE / OUTSAMPLE labeling:")
    for c in out.columns:
        print(f"  {c}")
    print("\nFor the manuscript's headline specificity/MCC gains, use the")
    print("*_OUTSAMPLE_* columns only. *_INSAMPLE_* columns are for internal")
    print("comparison/transparency, not for reporting as generalization evidence.")


if __name__ == "__main__":
    main()
