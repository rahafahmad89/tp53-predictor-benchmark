"""
02_classify_variants.py

Step 2: apply the agreed threshold/classification rules to every tool
column and produce a {TOOL}_call column (Pathogenic / Benign / VUS /
Missing) for each variant, in both the germline and somatic confident
benchmark files.

Scheme agreed on:

  Binary tools (Pathogenic/Benign, no VUS bucket):
    SIFT, REVEL, CADD (values 10-20 -> VUS, see below), ClinPred,
    MetaLR, MetaRNN, MetaSVM, MVP, Provean, DANN

  Three-way tools (Pathogenic/Benign/VUS, VUS rate reported as its own
  coverage stat, not folded into the binary confusion matrix):
    AlphaMissense, EVE, CADD-gray-zone (10-20 -> VUS)

  Kept but NOT thresholded / NOT scored against ground truth here:
    MaveDB               (functional evidence, handled separately)
    popEVE                (excluded per decision)
    MutPred2               (excluded per decision)
    MutationAssessor       (excluded per decision)
    MutationTaster          (excluded per decision)
    MutFormer                 (excluded per decision)

IMPORTANT — before running:
  1. Check the exact column names in your CSVs (run with
     PRINT_COLUMNS_ONLY = True first) and fix the "score_col" /
     "pred_col" entries in TOOL_CONFIG below to match exactly.
  2. EVE needs either a categorical class column (if your VEP/dbNSFP
     extraction already gives benign/uncertain/pathogenic classes) or,
     if it's a bare score, you need literature-confirmed cutoffs —
     the fallback below uses within-dataset 25th/75th percentiles as an
     interim measure and will print a loud warning if it's used, since
     that is a data-dependent split, not a validated clinical cutoff.
  3. Somatic file: this script assumes you're already handing it the
     117-variant confident file — no extra filtering happens here.
"""

import pandas as pd
import numpy as np

# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------

FILES = {
    # REVISION: v2 files = original files + PolyPhen-2 / BayesDel columns (merge_new_vep_scores.py)
    "germline": "germline_benchmark_final_v2.csv",
    "somatic": "somatic_benchmark_final_confident_v2.csv",
}

PRINT_COLUMNS_ONLY = False  # column names confirmed from your output — ready to classify

# Strings treated as missing across all categorical columns
MISSING_STRINGS = {"", ".", "-", "na", "n/a", "nan", None}


def _clean_str(x):
    if pd.isna(x):
        return None
    s = str(x).strip().lower()
    return None if s in MISSING_STRINGS else s


# ---- categorical value maps (case-insensitive, handles common dbNSFP codes) ----

DAMAGING_STRINGS = {"damaging", "deleterious", "d", "disease_causing", "possibly_damaging",
                     "probably_damaging"}
TOLERATED_STRINGS = {"tolerated", "neutral", "t", "n", "polymorphism", "benign"}


def classify_categorical(raw_value):
    v = _clean_str(raw_value)
    if v is None:
        return "Missing"
    if v in DAMAGING_STRINGS:
        return "Pathogenic"
    if v in TOLERATED_STRINGS:
        return "Benign"
    return f"UNRECOGNIZED:{v}"  # surface anything unexpected instead of silently mis-binning


def classify_numeric_binary(raw_value, threshold, higher_is_pathogenic=True):
    if pd.isna(raw_value):
        return "Missing"
    try:
        v = float(raw_value)
    except (ValueError, TypeError):
        return "Missing"
    if higher_is_pathogenic:
        return "Pathogenic" if v >= threshold else "Benign"
    else:
        return "Pathogenic" if v <= threshold else "Benign"


def classify_cadd(raw_value):
    if pd.isna(raw_value):
        return "Missing"
    try:
        v = float(raw_value)
    except (ValueError, TypeError):
        return "Missing"
    if v >= 20:
        return "Pathogenic"
    if v <= 10:
        return "Benign"
    return "VUS"  # 10 < v < 20 gray zone


def classify_alphamissense(raw_value):
    v = _clean_str(raw_value)
    if v is None:
        return "Missing"
    if "likely_pathogenic" in v or v == "likely pathogenic":
        return "Pathogenic"
    if "likely_benign" in v or v == "likely benign":
        return "Benign"
    if "ambiguous" in v:
        return "VUS"
    return f"UNRECOGNIZED:{v}"


def classify_eve(raw_value, low_cutoff=None, high_cutoff=None):
    """
    If raw_value is already a class string (benign/uncertain/pathogenic),
    map directly. Otherwise treat as numeric score and apply low/high
    cutoffs (score <= low -> Benign, score >= high -> Pathogenic, else VUS).
    """
    v = _clean_str(raw_value)
    if v is None:
        return "Missing"
    if v in ("benign", "likely_benign", "likely benign"):
        return "Benign"
    if v in ("pathogenic", "likely_pathogenic", "likely pathogenic"):
        return "Pathogenic"
    if v in ("uncertain", "vus"):
        return "VUS"
    # fall through: numeric score path
    try:
        score = float(raw_value)
    except (ValueError, TypeError):
        return f"UNRECOGNIZED:{v}"
    if low_cutoff is None or high_cutoff is None:
        return None  # signal to caller: needs percentile fallback
    if score >= high_cutoff:
        return "Pathogenic"
    if score <= low_cutoff:
        return "Benign"
    return "VUS"


# ---------------------------------------------------------------------------
# Tool configuration — EDIT column names to match your actual CSV headers
# ---------------------------------------------------------------------------

TOOL_CONFIG = {
    "SIFT":     {"kind": "categorical", "col": "SIFT_pred"},
    "REVEL":    {"kind": "numeric", "col": "REVEL_score", "threshold": 0.75, "higher_is_pathogenic": True},
    "CADD":     {"kind": "cadd_grayzone", "col": "CADD_score"},
    "ClinPred": {"kind": "categorical", "col": "ClinPred_pred"},
    "MetaLR":   {"kind": "categorical", "col": "MetaLR_pred"},
    "MetaRNN":  {"kind": "categorical", "col": "MetaRNN_pred"},
    "MetaSVM":  {"kind": "categorical", "col": "MetaSVM_pred"},
    "MVP":      {"kind": "numeric", "col": "MVP_score", "threshold": 0.75, "higher_is_pathogenic": True},
    "Provean":  {"kind": "categorical", "col": "PROVEAN_pred"},
    "DANN":     {"kind": "numeric", "col": "DANN_score", "threshold": 0.5, "higher_is_pathogenic": True},
    # REVISION (item 5): added tools, published binary cut-offs
    "PolyPhen2_HDIV": {"kind": "numeric", "col": "Polyphen2_HDIV_score", "threshold": 0.453, "higher_is_pathogenic": True},   # possibly+probably damaging
    "PolyPhen2_HVAR": {"kind": "numeric", "col": "Polyphen2_HVAR_score", "threshold": 0.447, "higher_is_pathogenic": True},   # possibly+probably damaging
    "BayesDel":       {"kind": "numeric", "col": "BayesDel_noAF_score",  "threshold": -0.0570105, "higher_is_pathogenic": True}, # dbNSFP BayesDel_noAF_pred cut-off
    # Both of these have their own confirmed _pred categorical column —
    # no percentile fallback needed. classify_eve/classify_alphamissense
    # will map the strings directly; UNRECOGNIZED will surface anything
    # that doesn't match the expected likely_benign/ambiguous/likely_pathogenic
    # (AlphaMissense) or benign/uncertain/pathogenic (EVE) vocab.
    "AlphaMissense": {"kind": "alphamissense", "col": "AlphaMissense_pred"},
    "EVE":      {"kind": "eve", "col": "EVE_pred"},
}

# Tools deliberately excluded from scoring — left here for documentation only
EXCLUDED_TOOLS = ["popEVE", "MutPred2", "MutationAssessor", "MutationTaster",
                   "MutFormer", "MaveDB"]


def classify_dataframe(df, tool_config):
    eve_percentile_used = False

    for tool, cfg in tool_config.items():
        col = cfg["col"]
        call_col = f"{tool}_call"

        if col not in df.columns:
            print(f"  [MISSING COLUMN] '{col}' for {tool} not found — "
                  f"filling {call_col} with 'Missing'")
            df[call_col] = "Missing"
            continue

        if cfg["kind"] == "categorical":
            df[call_col] = df[col].apply(classify_categorical)

        elif cfg["kind"] == "numeric":
            df[call_col] = df[col].apply(
                lambda x, t=cfg["threshold"], h=cfg["higher_is_pathogenic"]:
                classify_numeric_binary(x, t, h)
            )

        elif cfg["kind"] == "cadd_grayzone":
            df[call_col] = df[col].apply(classify_cadd)

        elif cfg["kind"] == "alphamissense":
            df[call_col] = df[col].apply(classify_alphamissense)

        elif cfg["kind"] == "eve":
            calls = df[col].apply(lambda x: classify_eve(x))
            if calls.isna().any():
                # numeric fallback needed — compute within-dataset percentiles
                eve_percentile_used = True
                numeric_scores = pd.to_numeric(df[col], errors="coerce")
                low_cutoff = numeric_scores.quantile(0.25)
                high_cutoff = numeric_scores.quantile(0.75)
                print(f"  [WARNING] EVE has no class labels / confirmed cutoffs — "
                      f"falling back to within-dataset 25th/75th percentile split "
                      f"(low={low_cutoff:.3f}, high={high_cutoff:.3f}). "
                      f"This is NOT a validated clinical cutoff — replace with a "
                      f"literature value before reporting in the paper.")
                calls = df[col].apply(
                    lambda x: classify_eve(x, low_cutoff, high_cutoff)
                )
            df[call_col] = calls

        # surface any unrecognized categorical values loudly
        unrecognized = df[call_col].astype(str).str.startswith("UNRECOGNIZED").sum()
        if unrecognized:
            examples = df.loc[
                df[call_col].astype(str).str.startswith("UNRECOGNIZED"), col
            ].unique()[:5]
            print(f"  [WARNING] {tool}: {unrecognized} unrecognized values in "
                  f"'{col}', examples: {list(examples)} — these need a mapping "
                  f"decision, currently left as UNRECOGNIZED (treated as missing "
                  f"in downstream benchmarking).")

    if eve_percentile_used:
        print("\n  >>> ACTION NEEDED: EVE used a data-dependent percentile "
              "fallback. Confirm literature cutoffs before finalizing results.")

    return df


def main():
    for name, path in FILES.items():
        print("=" * 70)
        print(f"DATASET: {name} ({path})")
        print("=" * 70)

        df = pd.read_csv(path)
        print(f"Loaded {df.shape[0]} rows, {df.shape[1]} columns")

        if PRINT_COLUMNS_ONLY:
            print("\nColumns in file (use this to fix TOOL_CONFIG col names):")
            for c in df.columns:
                print(f"  - {c}")
            continue

        # Quick diagnostic: show unique raw values for the categorical
        # 3-way tools before classifying, since a vocab mismatch here
        # silently produces UNRECOGNIZED calls otherwise.
        for check_col in ["AlphaMissense_pred", "EVE_pred"]:
            if check_col in df.columns:
                print(f"\n  Unique values in {check_col}: "
                      f"{sorted(df[check_col].dropna().unique().tolist())}")

        df = classify_dataframe(df, TOOL_CONFIG)

        out_path = f"{name}_classified.csv"
        df.to_csv(out_path, index=False)
        print(f"\nSaved: {out_path}")

        # quick call-distribution summary per tool
        print("\nCall distribution summary:")
        for tool in TOOL_CONFIG:
            call_col = f"{tool}_call"
            if call_col in df.columns:
                print(f"\n  {tool}:")
                print(df[call_col].value_counts(dropna=False).to_string())


if __name__ == "__main__":
    main()
