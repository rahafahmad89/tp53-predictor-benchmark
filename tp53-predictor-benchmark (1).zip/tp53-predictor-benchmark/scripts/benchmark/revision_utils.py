"""
revision_utils.py  -  shared helpers for the revision scripts 09-13.

Tool lists, score columns and directions are read from YOUR existing scripts
(03_benchmark_metrics.py and 05_suggest_thresholds.py), so there is one source
of truth: if you add a tool there, scripts 09-13 pick it up automatically.
The MCC-max threshold search reproduces find_mcc_threshold() in 05 exactly
(lowest threshold among ties), only faster, so bootstrap runs finish in minutes.
"""
import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import rankdata

HERE = Path(__file__).resolve().parent   # where 03/05 live (imported for tool settings)
DATA = Path.cwd()                        # data and outputs: the folder you run from (run_all.sh uses work/)
FILES = {"germline": DATA / "germline_classified.csv", "somatic": DATA / "somatic_classified.csv"}
DBD_RANGE = (94, 312)          # same as 06 and 07
N_BOOT = 2000
SEED = 20261030


def _load(fname, modname):
    spec = importlib.util.spec_from_file_location(modname, HERE / fname)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


M03 = _load("03_benchmark_metrics.py", "m03")
M05 = _load("05_suggest_thresholds.py", "m05")
TOOLS = M03.TOOL_CONFIG            # all benchmarked tools: score_col, higher_is_pathogenic, call_col
RECAL_TOOLS = M05.TOOL_CONFIG      # tools that get a recalibrated threshold


def load(name):
    df = pd.read_csv(FILES[name])
    y = pd.Series(np.nan, index=df.index)
    y[df["Binary_label"].isin(M03.PATHOGENIC_LABELS)] = 1
    y[df["Binary_label"].isin(M03.BENIGN_LABELS)] = 0
    df["y"] = y
    df["pos"] = pd.to_numeric(df["Protein_position"], errors="coerce")
    df["region"] = np.where(df["pos"].between(*DBD_RANGE), "DBD", "non-DBD")
    return df


def oriented(df, tool, cfg=TOOLS):
    s = pd.to_numeric(df[cfg[tool]["score_col"]], errors="coerce")
    return s if cfg[tool]["higher_is_pathogenic"] else -s


def auc(y, s):
    y = np.asarray(y, dtype=int); s = np.asarray(s, dtype=float)
    n1 = y.sum(); n0 = len(y) - n1
    if n1 == 0 or n0 == 0:
        return np.nan
    r = rankdata(s)
    return float((r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def mcc_threshold(y, s):
    """Same result as 05.find_mcc_threshold (ascending candidates, first maximum)."""
    y = np.asarray(y, dtype=int); s = np.asarray(s, dtype=float)
    u = np.unique(s)
    order = np.argsort(s)
    ys = y[order]; ss = s[order]
    # number of positives / predicted positives at threshold u[k] (pred = s >= u[k])
    idx = np.searchsorted(ss, u, side="left")
    P = y.sum(); n = len(y)
    cum_pos_from_top = np.r_[np.cumsum(ys[::-1])[::-1], 0]
    tp = cum_pos_from_top[idx].astype(float)
    npred = (n - idx).astype(float)
    fp = npred - tp; fn = P - tp; tn = (n - P) - fp
    den = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    with np.errstate(invalid="ignore", divide="ignore"):
        m = np.where(den > 0, (tp * tn - fp * fn) / den, 0.0)
    valid = (npred > 0) & (npred < n)
    m = np.where(valid, np.round(m, 12), -2)
    return float(u[int(np.argmax(m))])


def metrics(y, pred):
    y = np.asarray(y, dtype=int); p = np.asarray(pred, dtype=int)
    tp = ((y == 1) & (p == 1)).sum(); tn = ((y == 0) & (p == 0)).sum()
    fp = ((y == 0) & (p == 1)).sum(); fn = ((y == 1) & (p == 0)).sum()
    sens = tp / (tp + fn) if tp + fn else np.nan
    spec = tn / (tn + fp) if tn + fp else np.nan
    den = np.sqrt(float((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)))
    mcc = (tp * tn - fp * fn) / den if den > 0 else 0.0
    return {"sensitivity": sens, "specificity": spec, "mcc": mcc}


def boot_idx(y, rng):
    y = np.asarray(y)
    return np.concatenate([rng.choice(np.flatnonzero(y == k), (y == k).sum(), replace=True)
                           for k in np.unique(y)])


def ci(v):
    v = np.asarray(v, dtype=float); v = v[~np.isnan(v)]
    return (np.nan, np.nan) if len(v) == 0 else (np.percentile(v, 2.5), np.percentile(v, 97.5))


def fmt(est, lo, hi, nd=3):
    return "NA" if pd.isna(est) else f"{est:.{nd}f} ({lo:.{nd}f}–{hi:.{nd}f})"


def germline_mcc_thresholds():
    """Germline-derived MCC-max thresholds, on each tool's own scale, recomputed exactly as 05 does.
    (Not read from suggested_thresholds_summary.csv, because that file rounds them to 4 decimals and
    the rounding can move a variant across the threshold.)"""
    G = load("germline")
    out = {}
    for tool, cfg in RECAL_TOOLS.items():
        s = oriented(G, tool, RECAL_TOOLS); m = s.notna() & G.y.notna()
        t = mcc_threshold(G.y[m].to_numpy(int), s[m].to_numpy(float))
        out[tool] = t if cfg["higher_is_pathogenic"] else -t
    return out
