"""
07_md_candidate_selection.py

Step 7: surface candidate variants for molecular dynamics / structural
case studies.

Criteria (per your original plan):
  - Confidently labeled ground truth (already guaranteed — these are the
    binary benchmark files, VUS/conflicting already excluded)
  - Located in the DNA-binding domain (94-312) — richest structural
    data, and where PolyPhen's coverage gap already lives, so it ties
    the two findings together
  - Discordant: top-performing tools disagree with ground truth (or
    with each other) — these are the variants that best demonstrate
    "tool unreliability" structurally, not just statistically

"Top tools" here = the ones that showed real discriminative power in
your benchmarking (REVEL, ClinPred, MetaRNN, AlphaMissense, EVE,
Provean, SIFT) using their *_call columns already in the classified
files. MetaLR/MetaSVM/MVP/DANN are excluded from the consensus vote
since their *default* calls were shown to be near-degenerate — including
them would just be re-litigating the threshold problem, not adding
independent signal.

For each candidate, also reports whether MaveDB functional-assay data
exists (bonus: independent functional evidence anchors the structural
story if present, though its absence doesn't disqualify a candidate).

Produces two ranked shortlists:
  1. "Hidden pathogenic" — ground truth Pathogenic, most tools call Benign
  2. "False alarm benign" — ground truth Benign, most tools call Pathogenic
"""

import re
import pandas as pd
import numpy as np

# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------

FILES = {
    "germline": "germline_classified.csv",
    "somatic": "somatic_classified.csv",
}

LABEL_COL = "Binary_label"
PATHOGENIC_LABELS = {"Pathogenic", "pathogenic"}
BENIGN_LABELS = {"Benign", "benign"}

PROTEIN_POS_COL = "Protein_position"
DBD_RANGE = (94, 312)

# tools whose default call is trustworthy enough to vote in the consensus
TOP_TOOL_CALL_COLS = [
    "SIFT_call", "REVEL_call", "ClinPred_call", "MetaRNN_call",
    "Provean_call", "AlphaMissense_call", "EVE_call",
]

MAVEDB_COLS = ["MaveDB_score_raw", "MaveDB_score_mean"]

TOP_N_PER_LIST = 8

# ---------------------------------------------------------------------------


def parse_position(val):
    if pd.isna(val):
        return np.nan
    m = re.search(r"\d+", str(val))
    return int(m.group()) if m else np.nan


def binarize_labels(df, label_col):
    is_path = df[label_col].isin(PATHOGENIC_LABELS)
    is_ben = df[label_col].isin(BENIGN_LABELS)
    y = pd.Series(np.nan, index=df.index)
    y[is_path] = 1
    y[is_ben] = 0
    return y


def consensus_stats(row, ground_truth_value):
    """ground_truth_value: 'Pathogenic' or 'Benign' string to compare calls against."""
    calls = [row[c] for c in TOP_TOOL_CALL_COLS if c in row.index]
    scored = [c for c in calls if c in ("Pathogenic", "Benign")]
    if not scored:
        return np.nan, 0, 0
    n_agree = sum(1 for c in scored if c == ground_truth_value)
    n_disagree = len(scored) - n_agree
    disagree_rate = n_disagree / len(scored)
    return disagree_rate, len(scored), n_disagree


def main():
    for name, path in FILES.items():
        print("=" * 70)
        print(f"DATASET: {name} ({path})")
        print("=" * 70)

        df = pd.read_csv(path)
        y = binarize_labels(df, LABEL_COL)
        df["_y"] = y
        df["_position"] = df[PROTEIN_POS_COL].apply(parse_position)
        df["_in_dbd"] = (df["_position"] >= DBD_RANGE[0]) & (df["_position"] <= DBD_RANGE[1])

        has_mave = df[MAVEDB_COLS].notna().any(axis=1) if all(c in df.columns for c in MAVEDB_COLS) else pd.Series(False, index=df.index)
        df["_has_mavedb"] = has_mave

        dbd_labeled = df[df["_in_dbd"] & df["_y"].notna()].copy()
        print(f"\nDBD variants with confident ground truth: {len(dbd_labeled)} "
              f"({int((dbd_labeled['_y']==1).sum())} Pathogenic, "
              f"{int((dbd_labeled['_y']==0).sum())} Benign)")

        results = []
        for idx, row in dbd_labeled.iterrows():
            gt_str = "Pathogenic" if row["_y"] == 1 else "Benign"
            disagree_rate, n_scored, n_disagree = consensus_stats(row, gt_str)
            results.append({
                "Unified_ID": row.get("Unified_ID"),
                "HGVSp": row.get("HGVSp"),
                "Protein_position": row["_position"],
                "Ground_truth": gt_str,
                "n_tools_scored": n_scored,
                "n_tools_disagree": n_disagree,
                "disagree_rate": round(disagree_rate, 3) if not pd.isna(disagree_rate) else None,
                "has_MaveDB_evidence": bool(row["_has_mavedb"]),
            })

        res_df = pd.DataFrame(results)
        res_df = res_df[res_df["n_tools_scored"] >= 5]  # need a real consensus, not 1-2 tools

        hidden_pathogenic = res_df[res_df["Ground_truth"] == "Pathogenic"].sort_values(
            ["disagree_rate", "has_MaveDB_evidence"], ascending=[False, False]
        ).head(TOP_N_PER_LIST)

        false_alarm_benign = res_df[res_df["Ground_truth"] == "Benign"].sort_values(
            ["disagree_rate", "has_MaveDB_evidence"], ascending=[False, False]
        ).head(TOP_N_PER_LIST)

        print(f"\n--- Top {TOP_N_PER_LIST} 'Hidden Pathogenic' candidates "
              f"(true Pathogenic, most tools call Benign) ---")
        print(hidden_pathogenic.to_string(index=False))

        print(f"\n--- Top {TOP_N_PER_LIST} 'False Alarm Benign' candidates "
              f"(true Benign, most tools call Pathogenic) ---")
        print(false_alarm_benign.to_string(index=False))

        hidden_pathogenic.to_csv(f"md_candidates_hidden_pathogenic_{name}.csv", index=False)
        false_alarm_benign.to_csv(f"md_candidates_false_alarm_benign_{name}.csv", index=False)
        print(f"\nSaved: md_candidates_hidden_pathogenic_{name}.csv, "
              f"md_candidates_false_alarm_benign_{name}.csv")


if __name__ == "__main__":
    main()
