"""
01_missingness_report.py

Step 1 of the benchmarking pipeline: report per-tool missingness on the
germline and somatic confident benchmark sets, broken down by ground-truth
class (Pathogenic / Benign). No imputation, no dropping — this is a report
to inform which tools are usable, and the coverage numbers themselves are
part of the paper (ties into your existing REVEL/AlphaMissense ~56%
missingness finding).

USAGE:
    python 01_missingness_report.py

Edit the CONFIG block below to match your actual file paths and the
ground-truth column name in your CSVs before running.
"""

import pandas as pd

# ---------------------------------------------------------------------------
# CONFIG — edit these to match your files
# ---------------------------------------------------------------------------

FILES = {
    "germline": "germline_benchmark_final.csv",
    "somatic": "somatic_benchmark_final_confident.csv",
}

# Ground-truth label column — confirmed present in both files.
LABEL_COL = "Binary_label"

# Values in LABEL_COL that count as Pathogenic / Benign.
# NOTE: confirm these match your actual Binary_label values exactly — if the
# script prints "0 pathogenic / 0 benign found" below, the strings don't
# match and you need to adjust this set.
PATHOGENIC_LABELS = {"Pathogenic", "pathogenic", "Likely pathogenic", "Likely_pathogenic"}
BENIGN_LABELS = {"Benign", "benign", "Likely benign", "Likely_benign"}

# All tool columns present in both files (pred + score where both exist).
# Includes tools later excluded from the classification/benchmarking step
# (MutationAssessor, MutPred2, popEVE, MutFormer, MutationTaster, MaveDB) —
# still worth reporting their missingness for completeness/documentation.
SCORE_COLUMNS = [
    "SIFT_pred", "SIFT_score",
    "AlphaMissense_pred", "AlphaMissense_score",
    "ClinPred_pred", "ClinPred_score",
    "EVE_pred", "EVE_score",
    "MetaLR_pred", "MetaLR_score",
    "MetaRNN_pred", "MetaRNN_score",
    "MetaSVM_pred", "MetaSVM_score",
    "MutationAssessor_pred", "MutationAssessor_score",
    "PROVEAN_pred", "PROVEAN_score",
    "MutPred2_pred", "MutPred2_score",
    "REVEL_score",
    "CADD_score",
    "popEVE_score",
    "MutFormer_score",
    "DANN_score",
    "MVP_score",
    "MutationTaster_pred", "MutationTaster_score",
    "MaveDB_score_raw", "MaveDB_score_mean",
]

# ---------------------------------------------------------------------------


def load(path):
    df = pd.read_csv(path)
    print(f"\nLoaded {path}: {df.shape[0]} rows, {df.shape[1]} columns")
    return df


def auto_detect_columns(df):
    print("\nAll columns in file:")
    for c in df.columns:
        print(f"  - {c}")
    return list(df.columns)


def missingness_table(df, cols, label_col):
    has_labels = label_col in df.columns
    if not has_labels:
        print(f"  [WARNING] label column '{label_col}' not found — "
              f"skipping class-level breakdown, overall missingness only.")

    rows = []
    n_total = len(df)

    if has_labels:
        is_path = df[label_col].isin(PATHOGENIC_LABELS)
        is_ben = df[label_col].isin(BENIGN_LABELS)
        n_path = is_path.sum()
        n_ben = is_ben.sum()
        print(f"  Label match check: {n_path} Pathogenic, {n_ben} Benign "
              f"(out of {n_total} total rows)")
        if n_path == 0 or n_ben == 0:
            print(f"  [WARNING] one class has 0 matches — check actual values: "
                  f"{df[label_col].unique()[:10]}")

    for col in cols:
        if col not in df.columns:
            print(f"  [SKIP] column '{col}' not found in dataframe")
            continue
        n_missing = df[col].isna().sum()
        # also treat common placeholder strings as missing
        placeholder_missing = df[col].astype(str).str.strip().isin(
            ["", ".", "-", "NA", "N/A", "nan", "NaN"]
        ).sum()
        total_missing = df[col].isna() | df[col].astype(str).str.strip().isin(
            ["", ".", "-", "NA", "N/A", "nan", "NaN"]
        )
        pct_missing = 100 * total_missing.sum() / n_total

        row = {
            "tool_column": col,
            "n_missing": int(total_missing.sum()),
            "pct_missing": round(pct_missing, 1),
            "n_scored": n_total - int(total_missing.sum()),
        }

        if has_labels:
            path_missing = (total_missing & is_path).sum()
            ben_missing = (total_missing & is_ben).sum()
            row["pct_missing_in_pathogenic"] = (
                round(100 * path_missing / n_path, 1) if n_path else None
            )
            row["pct_missing_in_benign"] = (
                round(100 * ben_missing / n_ben, 1) if n_ben else None
            )

        rows.append(row)

    return pd.DataFrame(rows).sort_values("pct_missing", ascending=False)


def main():
    for name, path in FILES.items():
        print("=" * 70)
        print(f"DATASET: {name}  ({path})")
        print("=" * 70)

        df = load(path)

        cols = SCORE_COLUMNS
        if not cols:
            print("\nNo SCORE_COLUMNS configured — showing all columns so "
                  "you can fill in the list and re-run for a clean report.")
            auto_detect_columns(df)
            continue

        report = missingness_table(df, cols, LABEL_COL)
        print("\nMissingness report:")
        print(report.to_string(index=False))

        out_path = f"missingness_report_{name}.csv"
        report.to_csv(out_path, index=False)
        print(f"\nSaved: {out_path}")


if __name__ == "__main__":
    main()
