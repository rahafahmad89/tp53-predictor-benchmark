"""
11_domain_delta_auc.py  -  Revision items 4 (MetaLR DBD vs non-DBD test) and 22 (class counts).

DBD = residues 94-312, exactly as in 06 and 07.
Per tool, dataset and region: n, n pathogenic, n benign, AUC (95% CI; NA if a class has < 5 variants).
Per tool (germline): delta-AUC = AUC(DBD) - AUC(non-DBD), bootstrap 95% CI (each region resampled
separately) and a two-sided permutation p-value (region labels shuffled 5,000 times), BH-adjusted
across tools. DeLong's paired test does not apply: the two regions contain different variants.

Writes domain_stratified_ci.csv (Supplementary Table 3) and domain_delta_auc.csv
"""
import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests

import revision_utils as R

rng = np.random.default_rng(R.SEED)
B, NPERM, MIN_CLASS = R.N_BOOT, 5000, 5
strat, delta = [], []
for name in ("germline", "somatic"):
    d = R.load(name)
    for tool in R.TOOLS:
        s = R.oriented(d, tool); m = s.notna() & d.y.notna()
        sub = {"ALL": m, "DBD": m & (d.region == "DBD"), "non-DBD": m & (d.region == "non-DBD")}
        arr = {}
        for reg, mm in sub.items():
            y, x = d.y[mm].to_numpy(int), s[mm].to_numpy(float)
            npth, nben = int(y.sum()), int(len(y) - y.sum())
            if min(npth, nben) < MIN_CLASS:
                a, lo, hi = np.nan, np.nan, np.nan
            else:
                a = R.auc(y, x); lo, hi = R.ci([R.auc(y[i], x[i]) for i in (R.boot_idx(y, rng) for _ in range(B))])
            arr[reg] = (y, x, a)
            strat.append({"tool": tool, "dataset": name, "region": reg, "n": len(y), "n_pathogenic": npth,
                          "n_benign": nben, "AUC": round(a, 4) if a == a else np.nan, "AUC_95CI": R.fmt(a, lo, hi)})
        (y1, x1, a1), (y2, x2, a2) = arr["DBD"], arr["non-DBD"]
        if np.isnan(a1) or np.isnan(a2):
            continue
        bd = [R.auc(y1[i], x1[i]) - R.auc(y2[j], x2[j])
              for i, j in ((R.boot_idx(y1, rng), R.boot_idx(y2, rng)) for _ in range(B))]
        ya, xa, n1 = np.r_[y1, y2], np.r_[x1, x2], len(y1)
        obs, hits = a1 - a2, 0
        for _ in range(NPERM):
            p = rng.permutation(len(ya))
            da, db = R.auc(ya[p[:n1]], xa[p[:n1]]), R.auc(ya[p[n1:]], xa[p[n1:]])
            hits += (not np.isnan(da) and not np.isnan(db) and abs(da - db) >= abs(obs))
        delta.append({"tool": tool, "dataset": name, "AUC_DBD": round(a1, 3), "AUC_nonDBD": round(a2, 3),
                      "delta_AUC_95CI": R.fmt(obs, *R.ci(bd)), "perm_p": (hits + 1) / (NPERM + 1)})
dd = pd.DataFrame(delta)
for nm, g in dd.groupby("dataset"):
    dd.loc[g.index, "perm_p_BH"] = multipletests(g["perm_p"], method="fdr_bh")[1]
pd.DataFrame(strat).to_csv("domain_stratified_ci.csv", index=False)
dd.to_csv("domain_delta_auc.csv", index=False)
print(dd.to_string(index=False))
print("Saved: domain_stratified_ci.csv, domain_delta_auc.csv")
