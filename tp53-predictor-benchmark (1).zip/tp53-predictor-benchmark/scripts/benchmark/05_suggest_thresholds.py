"""
05_suggest_thresholds.py

Step 5: derive TP53-specific score thresholds for each tool, as an
alternative to the tools' published/default cutoffs.

Method (to avoid circularity — a threshold that fits your own data
trivially "works" on that data):
  - Derive a candidate threshold on ONE track (discovery set) using two
    criteria: Youden's J (max sensitivity+specificity-1) and MCC-max
    (best Matthews correlation coefficient, better suited to imbalance).
  - Validate that threshold OUT-OF-SAMPLE on the other track.
  - Do this in both directions (germline->somatic and somatic->germline)
    so you can see whether the suggested cutoff is stable across both
    tracks, not just an artifact of one dataset.
  - Compare against the tool's current/published/VEP-default performance
    (recomputed here from the same score column + published rule, for
    an apples-to-apples baseline).

Only run on tools with a genuine continuous score axis. AlphaMissense
and EVE are left out of this — they're inherently 3-class tools
(pathogenic/ambiguous/benign or pathogenic/uncertain/benign) and
collapsing them to a single binary cutoff would throw away that
structure; if you want optimized band edges for those two instead of a
single threshold, that's a different, separate analysis.
"""

import pandas as pd
import numpy as np
from sklearn.metrics import matthews_corrcoef, roc_curve

# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------

FILES = {
    "germline": "germline_classified.csv",
    "somatic": "somatic_classified.csv",
}

LABEL_COL = "Binary_label"
PATHOGENIC_LABELS = {"Pathogenic", "pathogenic"}
BENIGN_LABELS = {"Benign", "benign"}

# tool -> score_col, higher_is_pathogenic, published threshold (None if the
# tool only has a categorical published rule, e.g. from VEP's own pred
# column, with no single number in your reference table)
TOOL_CONFIG = {
    "SIFT":     {"score_col": "SIFT_score",     "higher_is_pathogenic": False, "published_threshold": None,
                 "published_note": "categorical only (Deleterious/Tolerated) in source table"},
    "REVEL":    {"score_col": "REVEL_score",    "higher_is_pathogenic": True,  "published_threshold": 0.75,
                 "published_note": "from source table"},
    "CADD":     {"score_col": "CADD_score",     "higher_is_pathogenic": True,  "published_threshold": 20.0,
                 "published_note": "from source table (>=20 path / <=10 benign; using 20 as single-cutoff comparator here)"},
    "ClinPred": {"score_col": "ClinPred_score", "higher_is_pathogenic": True,  "published_threshold": None,
                 "published_note": "categorical only (Damaging/Tolerated) in source table"},
    "MetaLR":   {"score_col": "MetaLR_score",   "higher_is_pathogenic": True,  "published_threshold": None,
                 "published_note": "categorical only (Damaging/Tolerated) in source table"},
    "MetaRNN":  {"score_col": "MetaRNN_score",  "higher_is_pathogenic": True,  "published_threshold": None,
                 "published_note": "categorical only (Damaging/Tolerated) in source table"},
    "MetaSVM":  {"score_col": "MetaSVM_score",  "higher_is_pathogenic": True,  "published_threshold": None,
                 "published_note": "categorical only (Damaging/Tolerated) in source table"},
    "MVP":      {"score_col": "MVP_score",      "higher_is_pathogenic": True,  "published_threshold": 0.75,
                 "published_note": "from source table"},
    "Provean":  {"score_col": "PROVEAN_score",  "higher_is_pathogenic": False, "published_threshold": None,
                 "published_note": "categorical only (Damaging/Neutral) in source table"},
    # REVISION (item 5)
    "PolyPhen2_HDIV": {"score_col": "Polyphen2_HDIV_score", "higher_is_pathogenic": True, "published_threshold": 0.453,
                 "published_note": "possibly/probably damaging >= 0.453 (HumDiv)"},
    "PolyPhen2_HVAR": {"score_col": "Polyphen2_HVAR_score", "higher_is_pathogenic": True, "published_threshold": 0.447,
                 "published_note": "possibly/probably damaging >= 0.447 (HumVar)"},
    "BayesDel": {"score_col": "BayesDel_noAF_score", "higher_is_pathogenic": True, "published_threshold": -0.0570105,
                 "published_note": "dbNSFP BayesDel_noAF_pred cut-off"},
    "DANN":     {"score_col": "DANN_score",     "higher_is_pathogenic": True,  "published_threshold": 0.5,
                 "published_note": "from source table"},
}

MIN_N = 10

# ---------------------------------------------------------------------------


def binarize_labels(df, label_col):
    is_path = df[label_col].isin(PATHOGENIC_LABELS)
    is_ben = df[label_col].isin(BENIGN_LABELS)
    y = pd.Series(np.nan, index=df.index)
    y[is_path] = 1
    y[is_ben] = 0
    return y


def oriented(score, higher_is_pathogenic):
    return score if higher_is_pathogenic else -score


def to_original_threshold(t_oriented, higher_is_pathogenic):
    return t_oriented if higher_is_pathogenic else -t_oriented


def apply_rule(score, threshold_original, higher_is_pathogenic):
    """Returns 1 (Pathogenic) / 0 (Benign) / NaN (missing)."""
    if pd.isna(score):
        return np.nan
    if higher_is_pathogenic:
        return 1 if score >= threshold_original else 0
    else:
        return 1 if score <= threshold_original else 0


def find_youden_threshold(y, score_oriented):
    fpr, tpr, thresholds = roc_curve(y, score_oriented)
    j = tpr - fpr
    best_idx = np.argmax(j)
    return thresholds[best_idx]


def find_mcc_threshold(y, score_oriented):
    candidates = np.unique(score_oriented)
    # subsample candidate thresholds if there are a lot, for speed
    if len(candidates) > 500:
        candidates = np.quantile(candidates, np.linspace(0, 1, 500))
    best_mcc = -2
    best_t = candidates[0]
    for t in candidates:
        pred = (score_oriented >= t).astype(int)
        if pred.sum() == 0 or pred.sum() == len(pred):
            continue
        mcc = matthews_corrcoef(y, pred)
        if mcc > best_mcc:
            best_mcc = mcc
            best_t = t
    return best_t


def evaluate_threshold(df, y_true, score_col, threshold_original, higher_is_pathogenic):
    preds = df[score_col].apply(
        lambda s: apply_rule(s, threshold_original, higher_is_pathogenic)
    )
    mask = preds.notna() & y_true.notna()
    n = mask.sum()
    if n < MIN_N:
        return {"n": int(n), "sensitivity": None, "specificity": None,
                "mcc": None, "balanced_accuracy": None}

    y = y_true[mask].astype(int)
    p = preds[mask].astype(int)
    tp = ((y == 1) & (p == 1)).sum()
    fn = ((y == 1) & (p == 0)).sum()
    tn = ((y == 0) & (p == 0)).sum()
    fp = ((y == 0) & (p == 1)).sum()

    sens = tp / (tp + fn) if (tp + fn) else None
    spec = tn / (tn + fp) if (tn + fp) else None
    mcc = matthews_corrcoef(y, p) if p.nunique() > 1 else None
    bal_acc = (sens + spec) / 2 if sens is not None and spec is not None else None

    return {
        "n": int(n),
        "sensitivity": round(sens, 4) if sens is not None else None,
        "specificity": round(spec, 4) if spec is not None else None,
        "mcc": round(mcc, 4) if mcc is not None else None,
        "balanced_accuracy": round(bal_acc, 4) if bal_acc is not None else None,
    }


def derive_and_validate(discovery_df, discovery_y, validate_df, validate_y,
                         score_col, higher_is_pathogenic):
    mask = discovery_df[score_col].notna() & discovery_y.notna()
    if mask.sum() < MIN_N or discovery_y[mask].nunique() < 2:
        return None

    y = discovery_y[mask].to_numpy(dtype=float)
    s_oriented = oriented(discovery_df.loc[mask, score_col].to_numpy(dtype=float),
                           higher_is_pathogenic)

    youden_t_oriented = find_youden_threshold(y, s_oriented)
    mcc_t_oriented = find_mcc_threshold(y, s_oriented)

    youden_t_original = to_original_threshold(youden_t_oriented, higher_is_pathogenic)
    mcc_t_original = to_original_threshold(mcc_t_oriented, higher_is_pathogenic)

    result = {
        "youden_threshold": round(float(youden_t_original), 4),
        "mcc_threshold": round(float(mcc_t_original), 4),
    }

    for label, t in [("youden", youden_t_original), ("mcc", mcc_t_original)]:
        in_sample = evaluate_threshold(discovery_df, discovery_y, score_col, t, higher_is_pathogenic)
        out_sample = evaluate_threshold(validate_df, validate_y, score_col, t, higher_is_pathogenic)
        for k, v in in_sample.items():
            result[f"{label}_insample_{k}"] = v
        for k, v in out_sample.items():
            result[f"{label}_outsample_{k}"] = v

    return result


def main():
    dfs = {}
    ys = {}
    for name, path in FILES.items():
        df = pd.read_csv(path)
        dfs[name] = df
        ys[name] = binarize_labels(df, LABEL_COL)

    all_rows = []

    for tool, cfg in TOOL_CONFIG.items():
        score_col = cfg["score_col"]
        hip = cfg["higher_is_pathogenic"]
        print("=" * 70)
        print(f"TOOL: {tool}  (score col: {score_col}, higher_is_pathogenic={hip})")
        print("=" * 70)

        row = {"tool": tool, "published_threshold": cfg["published_threshold"],
               "published_note": cfg["published_note"]}

        # current/published performance, evaluated on both tracks, if we
        # have a numeric published threshold to test
        if cfg["published_threshold"] is not None:
            for name in FILES:
                perf = evaluate_threshold(dfs[name], ys[name], score_col,
                                           cfg["published_threshold"], hip)
                for k, v in perf.items():
                    row[f"published_{name}_{k}"] = v
        else:
            print(f"  No numeric published threshold in source table for {tool} "
                  f"— skipping published-performance comparison, deriving "
                  f"TP53-specific threshold from scratch.")

        # germline -> somatic
        g2s = derive_and_validate(dfs["germline"], ys["germline"],
                                   dfs["somatic"], ys["somatic"],
                                   score_col, hip)
        if g2s:
            for k, v in g2s.items():
                row[f"germlineDiscovery_{k}"] = v
            print(f"  Germline-derived: Youden={g2s['youden_threshold']}, "
                  f"MCC-opt={g2s['mcc_threshold']}")
            print(f"    Youden -> germline(in-sample) sens={g2s['youden_insample_sensitivity']} "
                  f"spec={g2s['youden_insample_specificity']} | "
                  f"somatic(held-out) sens={g2s['youden_outsample_sensitivity']} "
                  f"spec={g2s['youden_outsample_specificity']}")
            print(f"    MCC-opt -> germline(in-sample) sens={g2s['mcc_insample_sensitivity']} "
                  f"spec={g2s['mcc_insample_specificity']} | "
                  f"somatic(held-out) sens={g2s['mcc_outsample_sensitivity']} "
                  f"spec={g2s['mcc_outsample_specificity']}")

        # somatic -> germline
        s2g = derive_and_validate(dfs["somatic"], ys["somatic"],
                                   dfs["germline"], ys["germline"],
                                   score_col, hip)
        if s2g:
            for k, v in s2g.items():
                row[f"somaticDiscovery_{k}"] = v
            print(f"  Somatic-derived:  Youden={s2g['youden_threshold']}, "
                  f"MCC-opt={s2g['mcc_threshold']}")
            print(f"    Youden -> somatic(in-sample) sens={s2g['youden_insample_sensitivity']} "
                  f"spec={s2g['youden_insample_specificity']} | "
                  f"germline(held-out) sens={s2g['youden_outsample_sensitivity']} "
                  f"spec={s2g['youden_outsample_specificity']}")
            print(f"    MCC-opt -> somatic(in-sample) sens={s2g['mcc_insample_sensitivity']} "
                  f"spec={s2g['mcc_insample_specificity']} | "
                  f"germline(held-out) sens={s2g['mcc_outsample_sensitivity']} "
                  f"spec={s2g['mcc_outsample_specificity']}")

        if g2s and s2g:
            youden_stability = abs(g2s["youden_threshold"] - s2g["youden_threshold"])
            mcc_stability = abs(g2s["mcc_threshold"] - s2g["mcc_threshold"])
            row["youden_threshold_stability_abs_diff"] = round(youden_stability, 4)
            row["mcc_threshold_stability_abs_diff"] = round(mcc_stability, 4)
            print(f"  Threshold stability (|germline-derived - somatic-derived|): "
                  f"Youden={youden_stability:.4f}, MCC-opt={mcc_stability:.4f}")

        all_rows.append(row)

    summary = pd.DataFrame(all_rows)
    summary.to_csv("suggested_thresholds_summary.csv", index=False)
    print("\n" + "=" * 70)
    print("Saved: suggested_thresholds_summary.csv")
    print("=" * 70)


if __name__ == "__main__":
    main()
