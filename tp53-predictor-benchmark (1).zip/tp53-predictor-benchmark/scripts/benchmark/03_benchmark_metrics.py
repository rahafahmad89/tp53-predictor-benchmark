"""
03_benchmark_metrics.py

Step 3: compute performance metrics for each tool against Binary_label,
on the classified germline and somatic files produced by
02_classify_variants.py.

Produces, per tool per dataset:
  - Coverage (% of variants with a usable score)
  - ROC-AUC and PR-AUC (average precision), from the continuous _score
    column, using only rows where that tool has a score (pairwise
    deletion — no imputation)
  - Confusion-matrix metrics from the *_call column (published threshold):
    sensitivity, specificity, PPV, NPV, accuracy, balanced accuracy,
    F1, MCC — computed on Pathogenic/Benign calls only (VUS and Missing
    calls excluded from this part, but counted and reported as a rate)
  - VUS rate (for AlphaMissense, EVE, CADD)

IMPORTANT: score direction. ROC-AUC assumes higher score = more likely
Pathogenic. Several tools are inverted (SIFT, PROVEAN). Directions below
are set from standard tool convention — if a tool's AUC comes out below
0.5, the script prints a loud warning since that almost always means a
direction error, not a genuinely anti-predictive tool.
"""

import pandas as pd
import numpy as np
from sklearn.metrics import (
    roc_auc_score, average_precision_score, confusion_matrix,
    matthews_corrcoef, balanced_accuracy_score, f1_score
)

# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------

FILES = {
    "germline": "germline_classified.csv",
    "somatic": "somatic_classified.csv",
}

LABEL_COL = "Binary_label"
PATHOGENIC_LABELS = {"Pathogenic", "pathogenic"}
BENIGN_LABELS = {"Benign", "benign"}

# tool -> (score_col, higher_is_pathogenic, call_col, has_vus)
TOOL_CONFIG = {
    "SIFT":          {"score_col": "SIFT_score",          "higher_is_pathogenic": False, "call_col": "SIFT_call",          "has_vus": False},
    "REVEL":         {"score_col": "REVEL_score",         "higher_is_pathogenic": True,  "call_col": "REVEL_call",         "has_vus": False},
    "CADD":          {"score_col": "CADD_score",          "higher_is_pathogenic": True,  "call_col": "CADD_call",          "has_vus": True},
    "ClinPred":      {"score_col": "ClinPred_score",      "higher_is_pathogenic": True,  "call_col": "ClinPred_call",      "has_vus": False},
    "MetaLR":        {"score_col": "MetaLR_score",        "higher_is_pathogenic": True,  "call_col": "MetaLR_call",        "has_vus": False},
    "MetaRNN":       {"score_col": "MetaRNN_score",       "higher_is_pathogenic": True,  "call_col": "MetaRNN_call",       "has_vus": False},
    "MetaSVM":       {"score_col": "MetaSVM_score",       "higher_is_pathogenic": True,  "call_col": "MetaSVM_call",       "has_vus": False},
    "MVP":           {"score_col": "MVP_score",           "higher_is_pathogenic": True,  "call_col": "MVP_call",           "has_vus": False},
    "Provean":       {"score_col": "PROVEAN_score",       "higher_is_pathogenic": False, "call_col": "Provean_call",       "has_vus": False},
    "DANN":          {"score_col": "DANN_score",          "higher_is_pathogenic": True,  "call_col": "DANN_call",          "has_vus": False},
    # REVISION (item 5)
    "PolyPhen2_HDIV": {"score_col": "Polyphen2_HDIV_score", "higher_is_pathogenic": True,  "call_col": "PolyPhen2_HDIV_call", "has_vus": False},
    "PolyPhen2_HVAR": {"score_col": "Polyphen2_HVAR_score", "higher_is_pathogenic": True,  "call_col": "PolyPhen2_HVAR_call", "has_vus": False},
    "BayesDel":       {"score_col": "BayesDel_noAF_score",  "higher_is_pathogenic": True,  "call_col": "BayesDel_call",       "has_vus": False},
    "AlphaMissense": {"score_col": "AlphaMissense_score", "higher_is_pathogenic": True,  "call_col": "AlphaMissense_call", "has_vus": True},
    "EVE":           {"score_col": "EVE_score",           "higher_is_pathogenic": True,  "call_col": "EVE_call",           "has_vus": True},
}

# ---------------------------------------------------------------------------


def binarize_labels(df, label_col):
    is_path = df[label_col].isin(PATHOGENIC_LABELS)
    is_ben = df[label_col].isin(BENIGN_LABELS)
    y = pd.Series(np.nan, index=df.index)
    y[is_path] = 1
    y[is_ben] = 0
    return y


def compute_auc_metrics(df, y_true, score_col, higher_is_pathogenic):
    mask = df[score_col].notna() & y_true.notna()
    n_used = mask.sum()
    if n_used < 10 or y_true[mask].nunique() < 2:
        return {"n_used": int(n_used), "roc_auc": None, "pr_auc": None,
                "note": "insufficient data (need both classes, n>=10)"}

    scores = df.loc[mask, score_col].astype(float)
    y = y_true[mask].astype(int)
    if not higher_is_pathogenic:
        scores = -scores

    roc_auc = roc_auc_score(y, scores)
    pr_auc = average_precision_score(y, scores)

    note = ""
    if roc_auc < 0.5:
        note = ("WARNING: AUC < 0.5 — likely a score-direction error, "
                 "check higher_is_pathogenic for this tool")

    return {"n_used": int(n_used), "roc_auc": round(roc_auc, 4),
            "pr_auc": round(pr_auc, 4), "note": note}


def compute_confusion_metrics(df, y_true, call_col):
    calls = df[call_col]
    mask = calls.isin(["Pathogenic", "Benign"]) & y_true.notna()
    n_used = mask.sum()
    n_vus = (calls == "VUS").sum()
    n_missing = (calls == "Missing").sum()
    n_total = len(df)

    if n_used < 10:
        return {"n_used": int(n_used), "n_vus": int(n_vus),
                "n_missing": int(n_missing),
                "vus_rate_pct": round(100 * n_vus / n_total, 1),
                "missing_rate_pct": round(100 * n_missing / n_total, 1),
                "sensitivity": None, "specificity": None, "ppv": None,
                "npv": None, "accuracy": None, "balanced_accuracy": None,
                "f1": None, "mcc": None,
                "note": "insufficient data for confusion matrix"}

    y_pred = (calls[mask] == "Pathogenic").astype(int)
    y = y_true[mask].astype(int)

    tn, fp, fn, tp = confusion_matrix(y, y_pred, labels=[0, 1]).ravel()
    sensitivity = tp / (tp + fn) if (tp + fn) else None
    specificity = tn / (tn + fp) if (tn + fp) else None
    ppv = tp / (tp + fp) if (tp + fp) else None
    npv = tn / (tn + fn) if (tn + fn) else None
    accuracy = (tp + tn) / n_used

    return {
        "n_used": int(n_used), "n_vus": int(n_vus), "n_missing": int(n_missing),
        "vus_rate_pct": round(100 * n_vus / n_total, 1),
        "missing_rate_pct": round(100 * n_missing / n_total, 1),
        "sensitivity": round(sensitivity, 4) if sensitivity is not None else None,
        "specificity": round(specificity, 4) if specificity is not None else None,
        "ppv": round(ppv, 4) if ppv is not None else None,
        "npv": round(npv, 4) if npv is not None else None,
        "accuracy": round(accuracy, 4),
        "balanced_accuracy": round(balanced_accuracy_score(y, y_pred), 4),
        "f1": round(f1_score(y, y_pred), 4),
        "mcc": round(matthews_corrcoef(y, y_pred), 4),
        "note": "",
    }


def main():
    for name, path in FILES.items():
        print("=" * 70)
        print(f"DATASET: {name} ({path})")
        print("=" * 70)

        df = pd.read_csv(path)
        y_true = binarize_labels(df, LABEL_COL)
        n_path = int((y_true == 1).sum())
        n_ben = int((y_true == 0).sum())
        print(f"Loaded {len(df)} rows — {n_path} Pathogenic, {n_ben} Benign "
              f"(ground truth)\n")

        rows = []
        for tool, cfg in TOOL_CONFIG.items():
            auc_metrics = compute_auc_metrics(
                df, y_true, cfg["score_col"], cfg["higher_is_pathogenic"]
            )
            conf_metrics = compute_confusion_metrics(df, y_true, cfg["call_col"])

            if auc_metrics.get("note"):
                print(f"  [{tool}] {auc_metrics['note']}")

            row = {"tool": tool}
            row.update({f"auc_{k}": v for k, v in auc_metrics.items() if k != "note"})
            row.update(conf_metrics)
            rows.append(row)

        summary = pd.DataFrame(rows)
        out_path = f"benchmark_summary_{name}.csv"
        summary.to_csv(out_path, index=False)

        print("\nSummary (ROC-AUC / PR-AUC / coverage):")
        print(summary[["tool", "auc_n_used", "auc_roc_auc", "auc_pr_auc"]]
              .to_string(index=False))

        print("\nSummary (confusion-matrix metrics at published threshold):")
        print(summary[["tool", "n_used", "vus_rate_pct", "missing_rate_pct",
                        "sensitivity", "specificity", "balanced_accuracy",
                        "mcc"]].to_string(index=False))

        print(f"\nSaved: {out_path}")


if __name__ == "__main__":
    main()
