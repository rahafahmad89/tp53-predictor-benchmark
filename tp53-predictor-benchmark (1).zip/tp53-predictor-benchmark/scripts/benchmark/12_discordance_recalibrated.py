"""
12_discordance_recalibrated.py  -  Revision item 3: how much discordance do the two failure modes explain?

Pairwise discordance is computed exactly as in 04 (percent of variants where both tools give a
Pathogenic/Benign call and the calls differ; VUS and missing excluded pair by pair), in four scenarios:
  S1  published default calls (the *_call columns from 02), whole gene   -> must equal 04's matrix
  S2  recalibrated: germline MCC thresholds from 05 for the tools in 05; AlphaMissense and EVE keep
      their native calls; applied unchanged to the somatic dataset          (removes failure mode 1)
  S3  default calls, DBD only (94-312)                                       (removes failure mode 2)
  S4  recalibrated, DBD only                                                 (removes both)
Per-variant discordance (fraction of calling tools that disagree with the reference label) is reported
for all tools and for the 7 "top tools" used by 07, and for the MD candidates.

Writes discordance_decomposition_summary.csv, discordance_decomposition_pairs.csv,
       discordance_candidates_recalibrated.csv, SuppFig_discordance_decomposition.png
"""
import itertools

import numpy as np
import pandas as pd

import revision_utils as R

M07 = R._load("07_md_candidate_selection.py", "m07")
TOP7 = [c.replace("_call", "") for c in M07.TOP_TOOL_CALL_COLS]
CANDIDATES = ["p.Arg110Leu", "p.Gly262Ser", "p.Glu171Lys", "p.Thr118Ile", "p.Ser106Arg"]
thr = R.germline_mcc_thresholds()


def calls(d, recal):
    C = pd.DataFrame(index=d.index)
    for tool, cfg in R.TOOLS.items():
        c = d[cfg["call_col"]].where(d[cfg["call_col"]].isin(["Pathogenic", "Benign"]))
        if recal and tool in thr:
            s = pd.to_numeric(d[cfg["score_col"]], errors="coerce")
            p = s >= thr[tool] if cfg["higher_is_pathogenic"] else s <= thr[tool]
            c = pd.Series(np.where(p, "Pathogenic", "Benign"), index=d.index).where(s.notna())
        C[tool] = c
    return C


def pairwise(C):
    out = []
    for a, b in itertools.combinations(C.columns, 2):
        m = C[a].notna() & C[b].notna()
        if m.sum():
            out.append({"tool_a": a, "tool_b": b, "n_both": int(m.sum()),
                        "discordance_pct": 100 * (C.loc[m, a] != C.loc[m, b]).mean()})
    return pd.DataFrame(out)


def per_variant(C, label):
    wrong = C.notna() & C.ne(label, axis=0)
    return wrong.sum(axis=1), C.notna().sum(axis=1)


summ, pairs, cand = [], [], []
for name in ("germline", "somatic"):
    d = R.load(name)
    for scen, recal, dbd in [("S1_default_whole_gene", False, False), ("S2_recalibrated_whole_gene", True, False),
                             ("S3_default_DBD", False, True), ("S4_recalibrated_DBD", True, True)]:
        sub = d[d.region == "DBD"] if dbd else d
        C = calls(sub, recal)
        pw = pairwise(C); pw.insert(0, "scenario", scen); pw.insert(0, "dataset", name); pairs.append(pw)
        nw, nc = per_variant(C, sub["Binary_label"])
        frac = nw / nc.replace(0, np.nan)
        top = max(pw.itertuples(), key=lambda r: r.discordance_pct)
        summ.append({"dataset": name, "scenario": scen, "n_variants": len(sub),
                     "max_pairwise_pct": round(top.discordance_pct, 1), "max_pair": f"{top.tool_a} vs {top.tool_b}",
                     "mean_pairwise_pct": round(pw.discordance_pct.mean(), 1),
                     "median_pairwise_pct": round(pw.discordance_pct.median(), 1),
                     "pairs_over_30pct": int((pw.discordance_pct > 30).sum()),
                     "mean_per_variant_discordance_pct": round(100 * frac.mean(), 1)})
        Ct = C[TOP7]; nw7, nc7 = per_variant(Ct, sub["Binary_label"])
        for v in CANDIDATES:
            for idx in sub.index[sub["HGVSp"].astype(str).str.endswith(v)]:
                cand.append({"dataset": name, "scenario": scen, "variant": v, "label": sub.at[idx, "Binary_label"],
                             "top7_wrong/called": f"{nw7[idx]}/{nc7[idx]}",
                             "all_tools_wrong/called": f"{nw[idx]}/{nc[idx]}",
                             "tools_wrong": ", ".join(t for t in C.columns
                                                      if pd.notna(C.at[idx, t]) and C.at[idx, t] != sub.at[idx, "Binary_label"])})
S = pd.DataFrame(summ)
for name in S.dataset.unique():
    m = S.dataset == name
    base = S[m & (S.scenario == "S1_default_whole_gene")].iloc[0]
    S.loc[m, "mean_pairwise_remaining_pct_of_S1"] = (100 * S.loc[m, "mean_pairwise_pct"] / base.mean_pairwise_pct).round(0)
    S.loc[m, "max_pairwise_remaining_pct_of_S1"] = (100 * S.loc[m, "max_pairwise_pct"] / base.max_pairwise_pct).round(0)
P = pd.concat(pairs)

# check S1 against 04's matrix
for name in ("germline", "somatic"):
    try:
        M = pd.read_csv(f"discordance_matrix_{name}.csv", index_col=0)
        p1 = P[(P.dataset == name) & (P.scenario == "S1_default_whole_gene")]
        diff = max(abs(M.loc[r.tool_a, r.tool_b] - r.discordance_pct) for r in p1.itertuples())
        print(f"S1 vs 04 discordance_matrix_{name}.csv: max difference {diff:.6f} (should be 0)")
    except FileNotFoundError:
        print(f"discordance_matrix_{name}.csv not found - run 04 first to cross-check S1")

S.to_csv("discordance_decomposition_summary.csv", index=False)
P.to_csv("discordance_decomposition_pairs.csv", index=False)
pd.DataFrame(cand).to_csv("discordance_candidates_recalibrated.csv", index=False)
print(S.to_string(index=False))
print(pd.DataFrame(cand)[["dataset", "scenario", "variant", "top7_wrong/called", "all_tools_wrong/called"]].to_string(index=False))

import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
order = ["S1_default_whole_gene", "S2_recalibrated_whole_gene", "S3_default_DBD", "S4_recalibrated_DBD"]
lab = ["Default\nwhole gene", "Recalibrated\nwhole gene", "Default\nDBD", "Recalibrated\nDBD"]
fig, axes = plt.subplots(1, 2, figsize=(9, 3.8), sharey=True)
for ax, name in zip(axes, ["germline", "somatic"]):
    vals = [P[(P.dataset == name) & (P.scenario == s)].discordance_pct.to_numpy() for s in order]
    ax.boxplot(vals, widths=0.5, showfliers=False)
    for k, v in enumerate(vals, 1):
        ax.scatter(np.random.default_rng(1).normal(k, 0.06, len(v)), v, s=9, alpha=0.6, color="#2F6690")
    ax.set_xticks(range(1, 5)); ax.set_xticklabels(lab, fontsize=8); ax.set_title(f"{name.capitalize()} dataset", fontsize=10)
    ax.spines[["top", "right"]].set_visible(False)
axes[0].set_ylabel("Pairwise discordance (%)")
fig.tight_layout(); fig.savefig("SuppFig_discordance_decomposition.png", dpi=300)
print("Saved: discordance_decomposition_summary.csv, discordance_decomposition_pairs.csv, "
      "discordance_candidates_recalibrated.csv, SuppFig_discordance_decomposition.png")
