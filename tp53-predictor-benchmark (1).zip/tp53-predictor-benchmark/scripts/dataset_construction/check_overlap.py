import pandas as pd
import re

GERM_PATH = "germline_classified.csv"
SOM_PATH  = "somatic_classified.csv"

germ = pd.read_csv(GERM_PATH)
som  = pd.read_csv(SOM_PATH)

def normalize_hgvsp(x):
    """ENSP00000269305.4:p.Glu388Gln -> p.Glu388Gln"""
    if pd.isna(x):
        return None
    m = re.search(r'p\.[A-Za-z]{3}\d+[A-Za-z]{3}', str(x))
    return m.group(0) if m else str(x).strip()

germ["prot_norm"] = germ["HGVSp"].apply(normalize_hgvsp)
som["prot_norm"]  = som["HGVSp"].apply(normalize_hgvsp)

# --- 1. Direct count: somatic variants explicitly corroborated via germline label ---
corrob_mask = som["Label_source_final"] == "germline_benign_corroborated"
print(f"Somatic variants labeled via germline-corroboration route: {corrob_mask.sum()}")

# --- 2. Full protein-change overlap between the two cohorts (any reason) ---
germ_keys = set(germ["prot_norm"].dropna())
som_keys  = set(som["prot_norm"].dropna())
overlap_keys = germ_keys & som_keys

print(f"Germline cohort size: {len(germ)}  (unique protein changes: {len(germ_keys)})")
print(f"Somatic cohort size: {len(som)}  (unique protein changes: {len(som_keys)})")
print(f"Total overlapping variants (by protein change, either cohort): {len(overlap_keys)}")

merged = germ.merge(som, on="prot_norm", suffixes=("_germ", "_som"))
merged["label_agrees"] = merged["Binary_label_germ"] == merged["Binary_label_som"]

out_cols = ["prot_norm", "Binary_label_germ", "Binary_label_som", "label_agrees",
            "Label_source_final"]
merged[out_cols].sort_values("prot_norm").to_csv("overlap_variants_report.csv", index=False)

print(f"\nLabel disagreements among overlapping variants: {(~merged['label_agrees']).sum()}")
print(merged[out_cols].to_string(index=False))

# --- 3. Flag the two MD candidates specifically ---
for v in ["p.Arg110Leu", "p.Gly262Ser"]:
    in_germ = v in germ_keys
    in_som  = v in som_keys
    print(f"\n{v}: in germline={in_germ}, in somatic={in_som}")
    if in_germ and in_som:
        g_row = germ[germ["prot_norm"] == v][["HGVSp", "Binary_label"]]
        s_row = som[som["prot_norm"] == v][["HGVSp", "Binary_label", "Label_source_final"]]
        print("  germline row:", g_row.to_dict("records"))
        print("  somatic row:", s_row.to_dict("records"))
