"""
Final confident somatic benchmark set:
  - Pathogenic: real ClinVar Oncogenicity_classification (Oncogenic/Likely oncogenic)
  - Benign: real ClinVar Oncogenicity_classification (Benign) PLUS variants whose
    VEP CLIN_SIG is benign-clean AND the identical protein change is independently
    classified Benign/Likely benign in the curated germline set (cross-source
    corroboration, not a blind proxy).
  - Everything else (VUS, no evidence, AF-only with <5% or no AF) is excluded.

Usage:
  python3 build_final_somatic_confident.py \
      vep_tp53_somatic_predictors_labeled.csv \
      vep_tp53_germline_predictors_labeled.csv \
      somatic_benchmark_final_confident.csv
"""
import sys
import pandas as pd


def classify_clinsig(val):
    if pd.isna(val) or val == '-':
        return 'no_annotation'
    tokens = set(t.strip() for t in val.split(','))
    pathogenic_tokens = {'pathogenic', 'likely_pathogenic', 'pathogenic/likely_pathogenic'}
    benign_tokens = {'benign', 'likely_benign', 'benign/likely_benign'}
    has_path = bool(tokens & pathogenic_tokens)
    has_benign = bool(tokens & benign_tokens)
    if 'conflicting_classifications_of_pathogenicity' in tokens:
        return 'conflicting_flag'
    if has_path and has_benign:
        return 'ambiguous_both'
    if has_path:
        return 'pathogenic_clean'
    if has_benign:
        return 'benign_clean'
    if tokens == {'uncertain_significance'}:
        return 'VUS_only'
    return 'other'


def main(somatic_csv, germline_csv, output_csv):
    df = pd.read_csv(somatic_csv, dtype=str)
    germline = pd.read_csv(germline_csv, dtype=str)
    germline_benign_ids = set(
        germline.loc[germline['Ground_truth_label'].str.contains('benign', case=False, na=False), 'Unified_ID']
    )

    df['clinsig_bucket'] = df['VEP_CLIN_SIG_reference'].apply(classify_clinsig)

    def assign(row):
        onc = row['Oncogenicity_classification']
        if pd.notna(onc):
            onc_l = str(onc).lower()
            if 'oncogenic' in onc_l:
                return 'Pathogenic', 'ClinVar_oncogenicity'
            if 'benign' in onc_l:
                return 'Benign', 'ClinVar_oncogenicity'
            return None, None  # real but non-binary (e.g. uncertain) -> excluded
        # no real oncogenicity call: only accept as Benign if CLIN_SIG-benign
        # AND independently corroborated by the curated germline benign set
        if row['clinsig_bucket'] == 'benign_clean' and row['Unified_ID'] in germline_benign_ids:
            return 'Benign', 'germline_benign_corroborated'
        return None, None

    results = df.apply(assign, axis=1, result_type='expand')
    df['Binary_label'] = results[0]
    df['Label_source_final'] = results[1]

    final = df[df['Binary_label'].notna()].copy()

    # sanity check: no variant should have two conflicting sources
    dupes = final[final.duplicated('Unified_ID', keep=False)]
    if len(dupes) > 0:
        print(f"WARNING: {dupes['Unified_ID'].nunique()} variants appear more than once - check for conflicts:")
        print(dupes[['Unified_ID', 'Binary_label', 'Label_source_final']].to_string())

    final.to_csv(output_csv, index=False)

    print("Final confident somatic benchmark set:")
    print(final.groupby(['Binary_label', 'Label_source_final']).size())
    print(f"\nTotal: {len(final)} variants "
          f"({(final['Binary_label']=='Pathogenic').sum()} Pathogenic, "
          f"{(final['Binary_label']=='Benign').sum()} Benign)")
    print(f"Saved: {output_csv}")


if __name__ == '__main__':
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(1)
    main(sys.argv[1], sys.argv[2], sys.argv[3])
