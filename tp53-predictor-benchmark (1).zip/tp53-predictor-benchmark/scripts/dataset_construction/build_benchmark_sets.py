"""
Build final benchmarking-ready datasets: confident Pathogenic/Benign labels only.
Drops VUS, Conflicting, Uncertain, and any ambiguous/unparseable labels.

Usage:
  python3 build_benchmark_sets.py germline vep_tp53_germline_predictors_labeled.csv germline_benchmark_final.csv
  python3 build_benchmark_sets.py somatic  vep_tp53_somatic_predictors_labeled.csv  somatic_benchmark_final.csv
"""
import sys
import pandas as pd


def normalize_binary_label(label):
    if pd.isna(label):
        return None
    l = str(label).lower()
    has_benign = 'benign' in l
    has_pathogenic = 'pathogenic' in l
    has_oncogenic = 'oncogenic' in l  # somatic vocabulary
    if has_oncogenic and not has_pathogenic:
        has_pathogenic = True
    if has_benign and has_pathogenic:
        return 'AMBIGUOUS'
    if has_benign:
        return 'Benign'
    if has_pathogenic:
        return 'Pathogenic'
    return 'UNRECOGNIZED'  # e.g. "Uncertain significance" alone


def build_germline(input_csv, output_csv):
    df = pd.read_csv(input_csv, dtype=str)
    df['Binary_label'] = df['Ground_truth_label'].apply(normalize_binary_label)

    print("Label bucket counts (pre-filter):")
    print(df['Binary_label'].value_counts(dropna=False))

    dropped = df[~df['Binary_label'].isin(['Pathogenic', 'Benign'])]
    if len(dropped) > 0:
        print(f"\nDropping {len(dropped)} rows (not confidently Pathogenic/Benign):")
        print(dropped[['Unified_ID', 'Ground_truth_label', 'Binary_label']].to_string())

    final = df[df['Binary_label'].isin(['Pathogenic', 'Benign'])].copy()
    final.to_csv(output_csv, index=False)
    print(f"\nFinal germline benchmark set: {len(final)} variants")
    print(final['Binary_label'].value_counts())
    print(f"Saved: {output_csv}")
    return final


def build_somatic(input_csv, output_csv):
    df = pd.read_csv(input_csv, dtype=str)
    # Only Oncogenicity_classification carries Benign<->Oncogenic vocabulary;
    # Somatic_clinical_impact (Tier I-IV) is an evidence-strength scale, not
    # a pathogenicity call, so it is NOT used for the binary label.
    df['Binary_label'] = df['Oncogenicity_classification'].apply(normalize_binary_label)

    print("Label bucket counts (pre-filter, based on Oncogenicity_classification only):")
    print(df['Binary_label'].value_counts(dropna=False))

    final = df[df['Binary_label'].isin(['Pathogenic', 'Benign'])].copy()
    final.to_csv(output_csv, index=False)
    print(f"\nFinal somatic benchmark set: {len(final)} variants")
    print(final['Binary_label'].value_counts())
    if (final['Binary_label'] == 'Benign').sum() < 10:
        print("\nWARNING: fewer than 10 confident Benign variants. Specificity/AUC-ROC")
        print("will not be statistically meaningful on this set. Consider reporting")
        print("sensitivity/recall only for the somatic track, or treating it as a")
        print("discordance-focused secondary analysis rather than a full benchmark.")
    print(f"Saved: {output_csv}")
    return final


if __name__ == '__main__':
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(1)
    mode, input_csv, output_csv = sys.argv[1], sys.argv[2], sys.argv[3]
    if mode == 'germline':
        build_germline(input_csv, output_csv)
    elif mode == 'somatic':
        build_somatic(input_csv, output_csv)
    else:
        print("First argument must be 'germline' or 'somatic'")
        sys.exit(1)
