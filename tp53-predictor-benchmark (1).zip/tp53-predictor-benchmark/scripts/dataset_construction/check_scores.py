import pandas as pd
import re

germ = pd.read_csv("germline_classified.csv")
som  = pd.read_csv("somatic_classified.csv")

def normalize_hgvsp(x):
    if pd.isna(x): return None
    m = re.search(r'p\.[A-Za-z]{3}\d+[A-Za-z]{3}', str(x))
    return m.group(0) if m else str(x).strip()

germ["prot_norm"] = germ["HGVSp"].apply(normalize_hgvsp)
som["prot_norm"]  = som["HGVSp"].apply(normalize_hgvsp)

score_cols = ["SIFT_score","AlphaMissense_score","ClinPred_score","EVE_score",
              "MetaLR_score","MetaRNN_score","MetaSVM_score","PROVEAN_score",
              "REVEL_score","CADD_score","DANN_score","MVP_score"]

merged = germ.merge(som, on="prot_norm", suffixes=("_germ","_som"))

for c in score_cols:
    g, s = f"{c}_germ", f"{c}_som"
    if g in merged.columns and s in merged.columns:
        match = (merged[g] == merged[s]).mean()
        print(f"{c}: {match:.1%} identical across cohort pairs")

for v in ["p.Arg110Leu", "p.Gly262Ser"]:
    row = merged[merged["prot_norm"] == v]
    print(f"\n{v}:")
    for c in score_cols:
        g, s = f"{c}_germ", f"{c}_som"
        if g in row.columns:
            print(f"  {c}: germ={row[g].values}, som={row[s].values}")
