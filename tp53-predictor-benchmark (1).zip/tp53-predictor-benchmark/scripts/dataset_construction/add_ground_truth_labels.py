"""
Attach REAL ground-truth pathogenicity labels (from raw ClinVar/ClinGen source
files, NOT from VEP's CLIN_SIG) to the predictor CSVs.

Germline label = ClinGen Expert Panel (wins conflicts) + ClinVar germline classification
Somatic labels = ClinVar somatic clinical impact + Oncogenicity classification (kept separate)
VEP's own CLIN_SIG is carried over only as a reference/sanity-check column, never as ground truth.

Usage:
  python3 add_ground_truth_labels.py germline \
      vep_tp53_germline_predictors.csv vep_tp53_germline_clean.tsv \
      clinvar_result_germline.txt erepo.report_clingen.csv \
      vep_tp53_germline_predictors_labeled.csv

  python3 add_ground_truth_labels.py somatic \
      vep_tp53_somatic_predictors.csv vep_tp53_somatic_clean.tsv \
      clinvar_result_somatic.txt \
      vep_tp53_somatic_predictors_labeled.csv
"""
import sys
import csv
import re
import pandas as pd


def normalize_key(s):
    """'NM_000546.6(TP53):c.1177G>T' -> 'NM_000546.6:c.1177G>T'"""
    if s is None:
        return None
    s = s.strip().strip('"')
    s = re.sub(r'\([^)]*\):', ':', s)
    return s


def hgvs_only(title):
    """Strip trailing ' (p.___)' from a Name/Title field."""
    return title.split(' (p.')[0]


def build_germline_labels(clinvar_path, clingen_path):
    labels = {}   # key -> (label, source)
    conflicts = []

    # ClinVar germline first (may be overwritten by ClinGen below)
    with open(clinvar_path, newline='', encoding='utf-8-sig') as f:
        reader = csv.reader(f, delimiter='\t')
        header = next(reader)
        for row in reader:
            name = row[0]
            germline_class = row[15]  # 'Germline classification'
            if not germline_class or germline_class == '-':
                continue
            key = normalize_key(hgvs_only(name))
            labels[key] = (germline_class, 'ClinVar_germline')

    # ClinGen Expert Panel — proper CSV parsing (fixes earlier awk misalignment bug)
    with open(clingen_path, newline='', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            title = row[0]
            classification = row[1]
            key = normalize_key(hgvs_only(title))
            if key in labels:
                prev_label, prev_source = labels[key]
                # Real conflict = different classification after normalizing case;
                # ClinVar/ClinGen sometimes differ only in capitalization ("Likely
                # pathogenic" vs "Likely Pathogenic"), which is not a true disagreement.
                if prev_label.lower() != classification.lower() and prev_source != 'ClinGen':
                    conflicts.append((key, labels[key], (classification, 'ClinGen')))
            labels[key] = (classification, 'ClinGen')  # ClinGen wins

    print(f"Germline labels built: {len(labels)} unique variants")
    if conflicts:
        print(f"  {len(conflicts)} REAL conflicts resolved in favor of ClinGen "
              f"(differ in more than capitalization; first 5 shown):")
        for key, old, new in conflicts[:5]:
            print(f"    {key}: ClinVar={old[0]!r} -> ClinGen={new[0]!r}")
    else:
        print("  0 real conflicts (any case-only differences were not counted)")

    return labels


def build_somatic_labels(clinvar_somatic_path):
    labels = {}  # key -> (somatic_impact, oncogenicity)
    with open(clinvar_somatic_path, newline='', encoding='utf-8-sig') as f:
        reader = csv.reader(f, delimiter='\t')
        header = next(reader)
        for row in reader:
            name = row[0]
            somatic_impact = row[18]       # 'Somatic clinical impact'
            oncogenicity = row[21]         # 'Oncogenicity classification'
            if (not somatic_impact or somatic_impact == '-') and (not oncogenicity or oncogenicity == '-'):
                continue
            key = normalize_key(hgvs_only(name))
            labels[key] = (somatic_impact if somatic_impact != '-' else None,
                           oncogenicity if oncogenicity != '-' else None)

    print(f"Somatic labels built: {len(labels)} unique variants")
    return labels


def attach_germline(predictors_csv, clean_tsv, clinvar_path, clingen_path, output_csv):
    labels = build_germline_labels(clinvar_path, clingen_path)

    pred = pd.read_csv(predictors_csv, dtype=str)
    clean = pd.read_csv(clean_tsv, sep='\t', dtype=str)[['Unified_ID', 'CLIN_SIG']]
    clean = clean.rename(columns={'CLIN_SIG': 'VEP_CLIN_SIG_reference'})

    pred['Ground_truth_label'] = pred['Unified_ID'].map(lambda k: labels.get(k, (None, None))[0])
    pred['Label_source'] = pred['Unified_ID'].map(lambda k: labels.get(k, (None, None))[1])

    out = pred.merge(clean, on='Unified_ID', how='left')

    n_labeled = out['Ground_truth_label'].notna().sum()
    print(f"\n{n_labeled}/{len(out)} predictor rows matched a ground-truth label")
    print(f"{len(out) - n_labeled} rows have no label (not in ClinVar-germline or ClinGen)")

    out.to_csv(output_csv, index=False)
    print(f"Saved: {output_csv}")
    return out


def attach_somatic(predictors_csv, clean_tsv, clinvar_somatic_path, output_csv):
    labels = build_somatic_labels(clinvar_somatic_path)

    pred = pd.read_csv(predictors_csv, dtype=str)
    clean = pd.read_csv(clean_tsv, sep='\t', dtype=str)[['Unified_ID', 'CLIN_SIG']]
    clean = clean.rename(columns={'CLIN_SIG': 'VEP_CLIN_SIG_reference'})

    pred['Somatic_clinical_impact'] = pred['Unified_ID'].map(lambda k: labels.get(k, (None, None))[0])
    pred['Oncogenicity_classification'] = pred['Unified_ID'].map(lambda k: labels.get(k, (None, None))[1])

    out = pred.merge(clean, on='Unified_ID', how='left')

    n_labeled = (out['Somatic_clinical_impact'].notna() | out['Oncogenicity_classification'].notna()).sum()
    print(f"\n{n_labeled}/{len(out)} predictor rows matched a ClinVar somatic/oncogenicity label")
    print(f"{len(out) - n_labeled} rows have no label (COSMIC-only variants, not in ClinVar-somatic)")

    out.to_csv(output_csv, index=False)
    print(f"Saved: {output_csv}")
    return out


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    mode = sys.argv[1]
    if mode == 'germline':
        _, _, predictors_csv, clean_tsv, clinvar_path, clingen_path, output_csv = sys.argv
        attach_germline(predictors_csv, clean_tsv, clinvar_path, clingen_path, output_csv)
    elif mode == 'somatic':
        _, _, predictors_csv, clean_tsv, clinvar_somatic_path, output_csv = sys.argv
        attach_somatic(predictors_csv, clean_tsv, clinvar_somatic_path, output_csv)
    else:
        print("First argument must be 'germline' or 'somatic'")
        sys.exit(1)
