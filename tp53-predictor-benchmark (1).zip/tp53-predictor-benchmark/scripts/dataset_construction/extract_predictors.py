"""
Extract pathogenicity-predictor-only columns from cleaned VEP output.
Splits combined "word(number)" fields (SIFT) into separate pred/score columns.
Handles MutationTaster's multi-value comma-separated format.
Keeps MaveDB as raw + mean (functional assay evidence, not a computational predictor).

Usage: python3 extract_predictors.py <input_vep.txt> <output.csv>
"""
import sys
import re
import pandas as pd


def split_word_number(val):
    """'deleterious(0.02)' -> ('deleterious', 0.02). Returns (None, None) if missing."""
    if pd.isna(val) or val == '-':
        return None, None
    m = re.match(r'^([a-zA-Z_]+)\(([-\d.eE]+)\)$', val.strip())
    if m:
        return m.group(1), float(m.group(2))
    return val, None  # fallback: keep raw string in pred, score unknown


def first_real_value(val):
    """MutationTaster-style: '.,.,.,.,D,.,.,.' -> 'D'. Returns None if all dots/missing."""
    if pd.isna(val) or val == '-':
        return None
    parts = [p.strip() for p in val.split(',')]
    for p in parts:
        if p and p != '.':
            return p
    return None


def mean_of_list(val):
    """MaveDB-style: '0.08,-0.23,0.77' -> mean. Returns None if missing/unparseable."""
    if pd.isna(val) or val == '-':
        return None
    try:
        parts = [float(p) for p in val.split(',')]
        return sum(parts) / len(parts)
    except ValueError:
        return None


def clean_and_extract(input_path, output_path):
    df = pd.read_csv(input_path, sep='\t', dtype=str, encoding='utf-8')
    print(f"Loaded {len(df)} raw rows, {df['#Uploaded_variation'].nunique()} unique variants")

    # Canonical Ensembl row only (preserves REVEL; see earlier QC)
    canon = df[(df['CANONICAL'] == 'YES') & (~df['Feature'].str.startswith('NM_'))].copy()

    # Missense only
    missense = canon[canon['Consequence'].str.contains('missense_variant')].copy()
    missense['is_pure_missense'] = missense['Consequence'] == 'missense_variant'

    # Unified ID
    def build_id(row):
        mane, hgvsc = row['MANE_SELECT'], row['HGVSc']
        if pd.isna(mane) or mane == '-' or pd.isna(hgvsc) or hgvsc == '-':
            return row['#Uploaded_variation']
        suffix = hgvsc.split(':', 1)[1] if ':' in hgvsc else hgvsc
        return f"{mane}:{suffix}"
    missense['Unified_ID'] = missense.apply(build_id, axis=1)

    # Dedup (same variant submitted under two transcript notations, e.g. ClinVar NM_ + COSMIC ENST)
    id_counts = missense['Unified_ID'].value_counts()
    missense['confirmed_multi_source'] = missense['Unified_ID'].map(id_counts) > 1
    before = len(missense)
    missense = missense.drop_duplicates(subset='Unified_ID', keep='first').copy()
    dropped = before - len(missense)
    print(f"Missense after dedup: {len(missense)} ({dropped} redundant rows dropped)")

    out = pd.DataFrame()
    out['Unified_ID'] = missense['Unified_ID']
    out['HGVSp'] = missense['HGVSp']
    out['Protein_position'] = missense['Protein_position']
    out['Amino_acids'] = missense['Amino_acids']
    out['is_pure_missense'] = missense['is_pure_missense']
    out['confirmed_multi_source'] = missense['confirmed_multi_source']

    # SIFT: split combined format
    sift_split = missense['SIFT'].apply(split_word_number)
    out['SIFT_pred'] = sift_split.apply(lambda t: t[0])
    out['SIFT_score'] = sift_split.apply(lambda t: t[1])

    # Already-split dbNSFP pred/score pairs: pass through directly
    passthrough_pairs = [
        ('am_class', 'am_pathogenicity', 'AlphaMissense'),
        ('ClinPred_pred', 'ClinPred_score', 'ClinPred'),
        ('EVE_CLASS', 'EVE_SCORE', 'EVE'),
        ('MetaLR_pred', 'MetaLR_score', 'MetaLR'),
        ('MetaRNN_pred', 'MetaRNN_score', 'MetaRNN'),
        ('MetaSVM_pred', 'MetaSVM_score', 'MetaSVM'),
        ('MutationAssessor_pred', 'MutationAssessor_score', 'MutationAssessor'),
        ('PROVEAN_pred', 'PROVEAN_score', 'PROVEAN'),
        ('MutPred2_pred', 'MutPred2_score', 'MutPred2'),
    ]
    for pred_col, score_col, label in passthrough_pairs:
        out[f'{label}_pred'] = missense[pred_col].replace('-', pd.NA)
        out[f'{label}_score'] = pd.to_numeric(missense[score_col].replace('-', pd.NA), errors='coerce')

    # Score-only (no categorical class provided by VEP)
    score_only = [
        ('REVEL_score', 'REVEL'),
        ('CADD_PHRED', 'CADD'),
        ('popEVE_SCORE', 'popEVE'),
        ('MutFormer_score', 'MutFormer'),
        ('DANN_score', 'DANN'),
        ('MVP_score', 'MVP'),
    ]
    for col, label in score_only:
        out[f'{label}_score'] = pd.to_numeric(missense[col].replace('-', pd.NA), errors='coerce')

    # MutationTaster: multi-value comma list, extract first real (non-'.') pred/score
    out['MutationTaster_pred'] = missense['MutationTaster_pred'].apply(first_real_value)
    out['MutationTaster_score'] = missense['MutationTaster_score'].apply(first_real_value)
    out['MutationTaster_score'] = pd.to_numeric(out['MutationTaster_score'], errors='coerce')

    # MaveDB: functional assay evidence, multi-value -> keep raw + mean
    out['MaveDB_score_raw'] = missense['MaveDB_score'].replace('-', pd.NA)
    out['MaveDB_score_mean'] = missense['MaveDB_score'].apply(mean_of_list)

    out = out.reset_index(drop=True)
    out.to_csv(output_path, index=False)
    print(f"Saved: {output_path} ({len(out)} rows, {len(out.columns)} columns)")

    # Quick missingness summary
    print("\nMissingness per predictor score:")
    score_cols = [c for c in out.columns if c.endswith('_score')]
    for c in score_cols:
        n_missing = out[c].isna().sum()
        print(f"  {c}: {n_missing}/{len(out)} ({100*n_missing/len(out):.1f}%)")

    return out


if __name__ == '__main__':
    if len(sys.argv) == 3:
        clean_and_extract(sys.argv[1], sys.argv[2])
    elif len(sys.argv) == 1:
        print("=" * 60, "\nGERMLINE\n", "=" * 60)
        clean_and_extract('vep_tp53_germline.txt', 'vep_tp53_germline_predictors.csv')
        print("\n" + "=" * 60, "\nSOMATIC\n", "=" * 60)
        clean_and_extract('vep_tp53_somatic.txt', 'vep_tp53_somatic_predictors.csv')
    else:
        print("Usage:")
        print("  python3 extract_predictors.py                          # both default files")
        print("  python3 extract_predictors.py <input_vep.txt> <out.csv> # one file")
        sys.exit(1)
