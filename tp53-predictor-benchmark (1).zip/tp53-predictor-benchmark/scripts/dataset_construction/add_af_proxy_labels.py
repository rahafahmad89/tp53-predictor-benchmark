"""
Augment somatic benchmark set with a population-frequency-based Benign proxy class,
per SBVS1 criterion (ClinGen/CGC/VICC oncogenicity standards, Horak et al. 2022,
Genetics in Medicine): gnomAD population MAF >= 5% is very strong evidence AGAINST
oncogenicity. This does not replace real ClinVar oncogenicity labels; it only fills
in a negative class for variants that have NO real oncogenicity assertion, so the
distinction (real vs proxy) is preserved in the output for transparency.

Usage:
  python3 add_af_proxy_labels.py vep_tp53_somatic.txt vep_tp53_somatic_predictors_labeled.csv \
      somatic_benchmark_with_proxy.csv
"""
import sys
import pandas as pd

SBVS1_THRESHOLD = 0.05  # gnomAD MAF >= 5% -> very strong evidence against oncogenicity


def extract_af(raw_vep_path):
    df = pd.read_csv(raw_vep_path, sep='\t', dtype=str, encoding='utf-8')
    canon = df[(df['CANONICAL'] == 'YES') & (~df['Feature'].str.startswith('NM_'))].copy()
    missense = canon[canon['Consequence'].str.contains('missense_variant')].copy()

    def build_id(row):
        mane, hgvsc = row['MANE_SELECT'], row['HGVSc']
        if pd.isna(mane) or mane == '-' or pd.isna(hgvsc) or hgvsc == '-':
            return row['#Uploaded_variation']
        suffix = hgvsc.split(':', 1)[1] if ':' in hgvsc else hgvsc
        return f"{mane}:{suffix}"
    missense['Unified_ID'] = missense.apply(build_id, axis=1)
    missense = missense.drop_duplicates(subset='Unified_ID', keep='first')

    af = missense[['Unified_ID', 'AF']].copy()
    af['AF'] = pd.to_numeric(af['AF'].replace('-', pd.NA), errors='coerce')
    return af


def main(raw_vep_path, labeled_csv, output_csv):
    af = extract_af(raw_vep_path)
    print(f"AF extracted for {af['AF'].notna().sum()}/{len(af)} variants "
          f"({100*af['AF'].notna().sum()/len(af):.1f}% have population frequency data)")

    df = pd.read_csv(labeled_csv, dtype=str)
    df = df.merge(af, on='Unified_ID', how='left')
    df['AF'] = pd.to_numeric(df['AF'], errors='coerce')

    def bucket(row):
        onc = row['Oncogenicity_classification']
        if pd.notna(onc):
            onc_l = str(onc).lower()
            if 'oncogenic' in onc_l:
                return 'Pathogenic', 'ClinVar_oncogenicity'
            if 'benign' in onc_l:
                return 'Benign', 'ClinVar_oncogenicity'
            return None, None  # uncertain/other -> excluded
        # no real label: check population frequency proxy
        if pd.notna(row['AF']) and row['AF'] >= SBVS1_THRESHOLD:
            return 'Benign', 'population_frequency_proxy_SBVS1'
        return None, None

    results = df.apply(bucket, axis=1, result_type='expand')
    df['Binary_label'] = results[0]
    df['Label_source_final'] = results[1]

    print("\nLabel source breakdown:")
    print(df['Label_source_final'].value_counts(dropna=False))
    print("\nBinary label breakdown:")
    print(df['Binary_label'].value_counts(dropna=False))

    final = df[df['Binary_label'].notna()].copy()
    final.to_csv(output_csv, index=False)
    print(f"\nFinal augmented somatic benchmark set: {len(final)} variants")
    print(final.groupby(['Binary_label', 'Label_source_final']).size())
    print(f"Saved: {output_csv}")

    n_benign = (final['Binary_label'] == 'Benign').sum()
    if n_benign < 10:
        print(f"\nWARNING: still only {n_benign} confident Benign variants even with the "
              f"SBVS1 proxy. TP53 hotspot positions are highly conserved, so common "
              f"population variants there are genuinely rare -- this may be a real "
              f"biological ceiling, not a pipeline gap.")


if __name__ == '__main__':
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(1)
    main(sys.argv[1], sys.argv[2], sys.argv[3])
