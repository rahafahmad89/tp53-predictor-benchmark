"""
Clean VEP TSV output: dedupe transcript rows, filter missense, unify ID, QC report.
Usage: python3 clean_vep.py <input_vep.txt> <output_clean.tsv>
"""
import sys
import pandas as pd

def clean_vep(input_path, output_path):
    df = pd.read_csv(input_path, sep='\t', dtype=str, encoding='utf-8')
    print(f"Loaded {len(df)} raw rows, {df['#Uploaded_variation'].nunique()} unique variants")

    # Keep canonical Ensembl transcript row only (preserves REVEL; all other
    # tool scores are identical between Ensembl/RefSeq canonical rows for TP53)
    canon = df[(df['CANONICAL'] == 'YES') & (~df['Feature'].str.startswith('NM_'))].copy()
    print(f"After canonical Ensembl filter: {len(canon)} rows, {canon['#Uploaded_variation'].nunique()} unique variants")

    dup_variants = canon['#Uploaded_variation'].value_counts()
    dup_variants = dup_variants[dup_variants > 1]
    if len(dup_variants) > 0:
        print(f"WARNING: {len(dup_variants)} variant(s) still have >1 canonical row:")
        print(dup_variants)

    # Missense filter (includes missense+splice_region combo calls, flagged separately)
    canon['is_pure_missense'] = canon['Consequence'] == 'missense_variant'
    missense = canon[canon['Consequence'].str.contains('missense_variant')].copy()
    print(f"Missense variants kept: {len(missense)} ({missense['is_pure_missense'].sum()} pure, "
          f"{(~missense['is_pure_missense']).sum()} missense+other)")

    # Unified ID: NM_ transcript + HGVSc suffix
    def build_id(row):
        mane = row['MANE_SELECT']
        hgvsc = row['HGVSc']
        if pd.isna(mane) or mane == '-' or pd.isna(hgvsc) or hgvsc == '-':
            return row['#Uploaded_variation']  # fallback
        suffix = hgvsc.split(':', 1)[1] if ':' in hgvsc else hgvsc
        return f"{mane}:{suffix}"

    missense['Unified_ID'] = missense.apply(build_id, axis=1)
    dupe_ids = missense['Unified_ID'].duplicated().sum()
    print(f"Duplicate Unified_ID after cleaning: {dupe_ids}")

    if dupe_ids > 0:
        # Same variant submitted under two different transcript notations
        # (e.g. ClinVar NM_ + COSMIC ENST for the same somatic mutation).
        # VEP's CLIN_SIG is genomic-position based, identical across duplicates,
        # so keep the first occurrence and drop the rest. Before dropping,
        # tag which variants were independently confirmed by both sources.
        id_counts = missense['Unified_ID'].value_counts()
        missense['confirmed_multi_source'] = missense['Unified_ID'].map(id_counts) > 1
        n_confirmed = missense.loc[missense['confirmed_multi_source'], 'Unified_ID'].nunique()
        print(f"  -> {n_confirmed} variants independently confirmed across multiple input sources")

        before = len(missense)
        missense = missense.drop_duplicates(subset='Unified_ID', keep='first').copy()
        print(f"  -> Dropped {before - len(missense)} redundant rows (kept first per Unified_ID)")
    else:
        missense['confirmed_multi_source'] = False

    # QC: missingness per predictor
    qc_cols = ['REVEL_score', 'CADD_PHRED', 'am_class', 'am_pathogenicity',
               'SIFT', 'PolyPhen', 'ClinPred_score', 'EVE_CLASS', 'EVE_SCORE']
    print("\nMissingness per predictor (of missense variants):")
    for c in qc_cols:
        if c in missense.columns:
            n_missing = (missense[c].isna() | (missense[c] == '-')).sum()
            pct = 100 * n_missing / len(missense)
            print(f"  {c}: {n_missing}/{len(missense)} missing ({pct:.1f}%)")
        else:
            print(f"  {c}: COLUMN NOT FOUND")

    # Output slim table with essential columns
    keep_cols = ['Unified_ID', '#Uploaded_variation', 'Feature', 'HGVSc', 'HGVSp',
                 'Protein_position', 'Amino_acids', 'Consequence', 'is_pure_missense',
                 'confirmed_multi_source', 'IMPACT', 'CLIN_SIG'] + qc_cols
    keep_cols = [c for c in keep_cols if c in missense.columns]
    out = missense[keep_cols].reset_index(drop=True)
    out.to_csv(output_path, sep='\t', index=False)
    print(f"\nSaved cleaned file: {output_path} ({len(out)} rows)")
    return out

if __name__ == '__main__':
    if len(sys.argv) == 3:
        # single file mode: python3 clean_vep.py <input_vep.txt> <output_clean.tsv>
        clean_vep(sys.argv[1], sys.argv[2])
    elif len(sys.argv) == 1:
        # default mode: clean both germline and somatic in one run
        print("=" * 60)
        print("GERMLINE")
        print("=" * 60)
        germline = clean_vep('vep_tp53_germline.txt', 'vep_tp53_germline_clean.tsv')

        print("\n" + "=" * 60)
        print("SOMATIC")
        print("=" * 60)
        somatic = clean_vep('vep_tp53_somatic.txt', 'vep_tp53_somatic_clean.tsv')

        print("\n" + "=" * 60)
        print("SUMMARY")
        print("=" * 60)
        print(f"Germline missense variants: {len(germline)}")
        print(f"Somatic missense variants:  {len(somatic)}")
    else:
        print("Usage:")
        print("  python3 clean_vep.py                              # cleans both default files")
        print("  python3 clean_vep.py <input_vep.txt> <output.tsv> # cleans one file")
        sys.exit(1)
