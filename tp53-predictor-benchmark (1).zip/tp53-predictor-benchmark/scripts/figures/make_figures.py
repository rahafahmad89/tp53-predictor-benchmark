"""Figures 1-4 and Supplementary Figure 1 for the revised TP53 benchmark manuscript (15 tools, 95% CIs).
Input: the result files from run_revision.sh (folder given as argv[1]); output: argv[2]."""
import re
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import leaves_list, linkage
from scipy.spatial.distance import squareform

IN, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
BLUE, RED, ORANGE, GREY = "#2166ac", "#b2182b", "#d6730f", "#8a8a8a"
INK, MUTED = "#222222", "#666666"
NAME = {"Provean": "PROVEAN", "PolyPhen2_HDIV": "PolyPhen-2 HDIV", "PolyPhen2_HVAR": "PolyPhen-2 HVAR"}
nm = lambda t: NAME.get(t, t)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": "#444444",
                     "axes.linewidth": 0.8, "xtick.color": "#444444", "ytick.color": "#444444",
                     "axes.labelcolor": INK, "text.color": INK, "legend.frameon": False})


def ci(s):
    m = re.match(r"\s*([-\d.]+)\s*\(([-\d.]+)\D+?([-\d.]+)\)", str(s))
    return tuple(map(float, m.groups())) if m else (np.nan, np.nan, np.nan)


def clean(ax, grid="x"):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis=grid, color="#e6e6e6", lw=0.6); ax.set_axisbelow(True)


def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(OUT / f"{name}.{ext}", dpi=600 if ext == "png" else None, bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------- Figure 1: AUC with 95% CI
t1 = pd.read_csv(IN / "table1_auc_ci.csv")
t1[["est", "lo", "hi"]] = t1["AUC_95CI"].apply(lambda s: pd.Series(ci(s)))
g = t1[t1.dataset == "germline"].set_index("tool"); s = t1[t1.dataset == "somatic"].set_index("tool")
order = g.sort_values("est").index.tolist()
fig, ax = plt.subplots(figsize=(6.2, 6.0))
y = np.arange(len(order))
for d, off, col, lab in [(g, 0.17, BLUE, f"Germline (n = {g.n_scored.min()}–{g.n_scored.max()} per tool)"),
                         (s, -0.17, RED, f"Somatic (n = {s.n_scored.min()}–{s.n_scored.max()} per tool)")]:
    dd = d.loc[order]
    ax.errorbar(dd.est, y + off, xerr=[dd.est - dd.lo, dd.hi - dd.est], fmt="o", ms=5, color=col,
                ecolor=col, elinewidth=1.4, capsize=0, label=lab)
ax.axvline(0.5, color=GREY, ls="--", lw=0.8); ax.text(0.505, len(order) - 0.4, "chance", color=MUTED, fontsize=8)
ax.set_yticks(y); ax.set_yticklabels([nm(t) for t in order]); ax.set_ylim(-0.6, len(order) - 0.2)
ax.set_xlim(0.4, 1.0); ax.set_xlabel("ROC-AUC (95% bootstrap CI)")
clean(ax); ax.legend(loc="lower right", fontsize=8)
save(fig, "Figure1_AUC_15tools")

# ---------------------------------------------------------------- Figure 2: discordance heatmaps
M = {k: pd.read_csv(IN / f"discordance_matrix_{k}.csv", index_col=0) for k in ("germline", "somatic")}
Dg = M["germline"].values.astype(float); Dg = (Dg + Dg.T) / 2; np.fill_diagonal(Dg, 0)
ordr = [M["germline"].index[i] for i in leaves_list(linkage(squareform(Dg), "average"))]
vmax = max(np.nanmax(m.values) for m in M.values())
fig, axes = plt.subplots(1, 2, figsize=(13.5, 6.3), gridspec_kw={"wspace": 0.38})
for ax, (k, title) in zip(axes, [("germline", "A  Germline dataset"), ("somatic", "B  Somatic dataset")]):
    A = M[k].loc[ordr, ordr].values.astype(float)
    im = ax.imshow(A, cmap="Reds", vmin=0, vmax=vmax)
    for i in range(len(ordr)):
        for j in range(len(ordr)):
            if i != j:
                ax.text(j, i, f"{A[i, j]:.0f}", ha="center", va="center", fontsize=6,
                        color="white" if A[i, j] > vmax * 0.55 else INK)
    ax.set_xticks(range(len(ordr))); ax.set_xticklabels([nm(t) for t in ordr], rotation=90, fontsize=8)
    ax.set_yticks(range(len(ordr))); ax.set_yticklabels([nm(t) for t in ordr], fontsize=8)
    ax.set_xticks(np.arange(-.5, len(ordr)), minor=True); ax.set_yticks(np.arange(-.5, len(ordr)), minor=True)
    ax.grid(which="minor", color="white", lw=0.8); ax.tick_params(which="minor", length=0)
    for sp in ax.spines.values(): sp.set_visible(False)
    ax.set_title(title, loc="left", fontsize=11, fontweight="bold")
cb = fig.colorbar(im, ax=axes, fraction=0.025, pad=0.02); cb.set_label("Pairwise discordance (% of variants called by both tools)")
cb.outline.set_visible(False)
save(fig, "Figure2_discordance_15tools")

# ---------------------------------------------------------------- Figure 3: recalibration dumbbells
t2 = pd.read_csv(IN / "table2_recalibration_ci.csv").set_index("tool")
gd = g  # default metrics with CI, germline
cvcol = lambda m: [c for c in t2.columns if c.startswith(f"{m}_germline_CV5x50")][0]
tools3 = gd.loc[t2.index, "default_specificity_95CI"].apply(lambda s: ci(s)[0]).sort_values(ascending=False).index.tolist()
fig, axes = plt.subplots(1, 2, figsize=(11.5, 5.4), sharey=True, gridspec_kw={"wspace": 0.08})
for ax, metric, lab, scale in [(axes[0], "specificity", "Specificity (%)", 100), (axes[1], "mcc", "MCC", 1)]:
    yy = np.arange(len(tools3))
    for i, t in enumerate(tools3):
        d0 = ci(gd.loc[t, f"default_{metric}_95CI"]); r = ci(t2.loc[t, f"{metric}_germline_insample"])
        cv = ci(t2.loc[t, cvcol(metric)])[0]
        ax.plot([d0[0] * scale, r[0] * scale], [i, i], color="#c8c8c8", lw=2, zorder=1, solid_capstyle="round")
        ax.errorbar(d0[0] * scale, i, xerr=[[(d0[0] - d0[1]) * scale], [(d0[2] - d0[0]) * scale]], fmt="o", ms=6,
                    color=RED, elinewidth=1.2, zorder=3, label="Published default threshold" if i == 0 else None)
        ax.errorbar(r[0] * scale, i, xerr=[[(r[0] - r[1]) * scale], [(r[2] - r[0]) * scale]], fmt="o", ms=6,
                    color=BLUE, elinewidth=1.2, zorder=3, label="MCC-max threshold, in-sample" if i == 0 else None)
        ax.plot(cv * scale, i, marker="D", ms=5, mfc="white", mec=BLUE, mew=1.3, ls="none", zorder=4,
                label="MCC-max threshold, cross-validated" if i == 0 else None)
    ax.set_yticks(yy); ax.set_yticklabels([nm(t) for t in tools3]); ax.invert_yaxis()
    ax.set_xlabel(lab.replace(" (%)", ", %") + " (95% bootstrap CI)"); clean(ax)
    ax.set_xlim(0, 100 if scale == 100 else 1)
axes[0].set_title("A  Specificity", loc="left", fontsize=11, fontweight="bold")
axes[1].set_title("B  Matthews correlation coefficient", loc="left", fontsize=11, fontweight="bold")
h, l = axes[0].get_legend_handles_labels()
want = ["Published default threshold", "MCC-max threshold, in-sample", "MCC-max threshold, cross-validated"]
axes[0].legend([h[l.index(w)] for w in want], want, loc="lower left", bbox_to_anchor=(0, -0.28), ncol=3, fontsize=8)
save(fig, "Figure3_recalibration_15tools")

# ---------------------------------------------------------------- Figure 4: DBD vs non-DBD AUC
dm = pd.read_csv(IN / "domain_stratified_ci.csv"); dm = dm[dm.dataset == "germline"]
dm[["est", "lo", "hi"]] = dm["AUC_95CI"].apply(lambda s: pd.Series(ci(s)))
dl = pd.read_csv(IN / "domain_delta_auc.csv"); dl = dl[dl.dataset == "germline"].set_index("tool")
dbd = dm[dm.region == "DBD"].set_index("tool"); non = dm[dm.region == "non-DBD"].set_index("tool")
order4 = (dbd.est - non.est).sort_values(ascending=False).index.tolist()
fig, ax = plt.subplots(figsize=(10.5, 4.8))
x = np.arange(len(order4))
for d, off, col, lab in [(dbd, -0.16, BLUE, f"DBD, residues 94–312 (n = {int(dbd.n.min())}–{int(dbd.n.max())})"),
                         (non, 0.16, ORANGE, f"Outside DBD (n = {int(non.n.min())}–{int(non.n.max())}; 12–13 pathogenic)")]:
    dd = d.loc[order4]
    ax.errorbar(x + off, dd.est, yerr=[dd.est - dd.lo, dd.hi - dd.est], fmt="o", ms=5.5, color=col,
                elinewidth=1.3, label=lab)
ax.axhline(0.5, color=GREY, ls="--", lw=0.8)
for t in order4:
    if dl.loc[t, "perm_p_BH"] < 0.05:
        i = order4.index(t); dv = float(dl.loc[t, "delta_AUC_95CI"].split()[0])
        txt = f"ΔAUC = {dv:.2f}".replace("-", "−") + f"\nBH p = {dl.loc[t, 'perm_p_BH']:.3f}"
        if dv > 0:
            ax.text(i, max(dbd.loc[t, "hi"], non.loc[t, "hi"]) + 0.03, txt, ha="center", va="bottom", fontsize=7.5)
        else:
            ax.text(i, min(dbd.loc[t, "lo"], non.loc[t, "lo"]) - 0.03, txt, ha="center", va="top", fontsize=7.5)
ax.set_xticks(x); ax.set_xticklabels([nm(t) for t in order4], rotation=40, ha="right")
ax.set_ylim(-0.02, 1.15); ax.set_yticks(np.arange(0, 1.01, 0.2)); ax.set_ylabel("ROC-AUC (95% bootstrap CI)")
clean(ax, grid="y"); ax.legend(loc="lower left", fontsize=8, ncol=1)
save(fig, "Figure4_domain_15tools")

# ---------------------------------------------------------------- Supplementary Figure 1: discordance decomposition
sm = pd.read_csv(IN / "discordance_decomposition_summary.csv")
sc = ["S1_default_whole_gene", "S2_recalibrated_whole_gene", "S3_default_DBD", "S4_recalibrated_DBD"]
lab = ["Default\nwhole gene", "Recalibrated\nwhole gene", "Default\nDBD only", "Recalibrated\nDBD only"]
fig, ax = plt.subplots(figsize=(7.2, 4.0))
w = 0.36
for k, (ds, col) in enumerate([("germline", BLUE), ("somatic", RED)]):
    v = sm[sm.dataset == ds].set_index("scenario").loc[sc, "mean_pairwise_pct"].values
    b = ax.bar(np.arange(4) + (k - 0.5) * (w + 0.02), v, w, color=col, label=ds.capitalize() + " dataset")
    for xi, vi in zip(np.arange(4) + (k - 0.5) * (w + 0.02), v):
        ax.text(xi, vi + 0.3, f"{vi:.1f}", ha="center", va="bottom", fontsize=8, color=INK)
ax.set_xticks(range(4)); ax.set_xticklabels(lab); ax.set_ylabel("Mean pairwise discordance (%)")
ax.set_ylim(0, 19); clean(ax, grid="y"); ax.legend(fontsize=8)
save(fig, "SuppFigure1_discordance_decomposition")
print("done:", sorted(p.name for p in OUT.iterdir()))
