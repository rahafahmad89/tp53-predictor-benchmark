import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

IN = Path(sys.argv[1]); OUT = Path(sys.argv[2]); RAW = Path(sys.argv[3]); EXTRA = Path(sys.argv[4])
NAME = {"Provean": "PROVEAN", "PolyPhen2_HDIV": "PolyPhen-2 HDIV", "PolyPhen2_HVAR": "PolyPhen-2 HVAR"}
nm = lambda t: NAME.get(t, t)


def ci(s):
    m = re.match(r"\s*([-\d.]+)\s*\(([-\d.]+)\D+?([-\d.]+)\)", str(s))
    return tuple(map(float, m.groups())) if m else (np.nan,) * 3


def pct(s, nd=1):
    e, l, h = ci(s)
    return "NA" if np.isnan(e) else f"{100*e:.{nd}f} ({100*l:.{nd}f}–{100*h:.{nd}f})"


def num(s, nd=3):
    e, l, h = ci(s)
    return "NA" if np.isnan(e) else f"{e:.{nd}f} ({l:.{nd}f}–{h:.{nd}f})"


doc = Document()
st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(9)
sec = doc.sections[0]; sec.orientation = WD_ORIENT.LANDSCAPE
sec.page_width, sec.page_height = Cm(29.7), Cm(21.0)
for m in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
    setattr(sec, m, Cm(1.6))


def shade(cell, hexcol):
    tcPr = cell._tc.get_or_add_tcPr(); sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto"); sh.set(qn("w:fill"), hexcol); tcPr.append(sh)


def table(title, header, rows, notes=(), group_rows=()):
    p = doc.add_paragraph(); r = p.add_run(title); r.bold = True; r.font.size = Pt(10)
    t = doc.add_table(rows=1, cols=len(header)); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for c, h in zip(t.rows[0].cells, header):
        c.text = ""; run = c.paragraphs[0].add_run(h); run.bold = True; run.font.size = Pt(8); shade(c, "E7EEF6")
    for i, row in enumerate(rows):
        cells = t.add_row().cells
        if i in group_rows:
            m = cells[0].merge(cells[-1]); m.text = ""; rr = m.paragraphs[0].add_run(row[0]); rr.bold = True
            rr.font.size = Pt(8); shade(m, "F2F2F2"); continue
        for c, v in zip(cells, row):
            c.text = ""; rr = c.paragraphs[0].add_run(str(v)); rr.font.size = Pt(8)
    for n in notes:
        q = doc.add_paragraph(); rn = q.add_run(n); rn.font.size = Pt(7.5); rn.italic = True
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)


t1 = pd.read_csv(IN / "table1_auc_ci.csv")
bs = {d: pd.read_csv(IN / f"benchmark_summary_{d}.csv").set_index("tool") for d in ("germline", "somatic")}
order = t1[t1.dataset == "germline"].assign(e=lambda d: d.AUC).sort_values("e", ascending=False).tool.tolist()

# ------------- Table 1
rows, groups = [], []
for d in ("germline", "somatic"):
    groups.append(len(rows)); rows.append([f"{d.capitalize()} dataset"])
    sub = t1[t1.dataset == d].set_index("tool")
    for t in order:
        r = sub.loc[t]
        rows.append([nm(t), int(r.n_scored), num(r.AUC_95CI), int(r.n_called_default),
                     pct(r.default_sensitivity_95CI), pct(r.default_specificity_95CI), num(r.default_mcc_95CI)])
table("Table 1: Discriminative performance and classification at published default thresholds, per tool and dataset.",
      ["Tool", "n scored", "ROC-AUC (95% CI)", "n called", "Sensitivity, % (95% CI)", "Specificity, % (95% CI)", "MCC (95% CI)"],
      rows, ["Tools sorted by germline ROC-AUC. 95% CIs: stratified bootstrap, 2,000 resamples. “n called” excludes "
             "indeterminate calls (CADD 10–20; AlphaMissense ambiguous; EVE uncertain). PR-AUC, PPV, NPV, accuracy, F1 and "
             "balanced accuracy are in Supplementary Table 5."], groups)

# ------------- Table 2
t2 = pd.read_csv(IN / "table2_recalibration_ci.csv").set_index("tool")
cv = lambda m: [c for c in t2.columns if c.startswith(f"{m}_germline_CV5x50")][0]
pub = {"SIFT": "< 0.05 (deleterious)", "REVEL": "≥ 0.75", "CADD": "≥ 20 (PHRED)ᵃ", "ClinPred": "≥ 0.5",
       "MetaLR": "≥ 0.5", "MetaRNN": "≥ 0.5", "MetaSVM": "> 0", "MVP": "≥ 0.75", "Provean": "≤ −2.5",
       "DANN": "≥ 0.5", "PolyPhen2_HDIV": "≥ 0.453", "PolyPhen2_HVAR": "≥ 0.447", "BayesDel": "> −0.057"}
g1 = t1[t1.dataset == "germline"].set_index("tool")
o2 = sorted(t2.index, key=lambda t: ci(g1.loc[t, "default_specificity_95CI"])[0])
rows = []
for t in o2:
    r = t2.loc[t]
    rows.append([nm(t), pub[t], f"{r.germline_MCC_threshold:g}",
                 pct(g1.loc[t, "default_specificity_95CI"]), pct(r.specificity_germline_insample),
                 f"{100*ci(r[cv('specificity')])[0]:.1f}", pct(r.specificity_somatic),
                 num(g1.loc[t, "default_mcc_95CI"]), num(r.mcc_germline_insample), f"{ci(r[cv('mcc')])[0]:.3f}", num(r.mcc_somatic)])
table("Table 2: Threshold recalibration. Published default vs germline-derived MCC-maximised thresholds.",
      ["Tool", "Published threshold (pathogenic if)", "MCC-max threshold (germline)", "Specificity %, default (germline)",
       "Specificity %, recalibrated, in-sample (germline)", "Specificity %, recalibrated, cross-validated (germline)",
       "Specificity %, recalibrated (somatic)", "MCC, default (germline)", "MCC, recalibrated, in-sample (germline)",
       "MCC, cross-validated (germline)", "MCC, recalibrated (somatic)"], rows,
      ["Sorted by default specificity. Cross-validated = mean over 50 repeats of stratified five-fold cross-validation, threshold "
       "derived on training folds only. Somatic = germline-derived threshold applied unchanged to the somatic dataset; because all "
       "somatic substitutions are also in the germline dataset, this is not an independent out-of-sample test. SIFT, ClinPred, MetaLR, "
       "MetaRNN, MetaSVM and PROVEAN default calls are the categorical predictions distributed with dbNSFP, which apply the "
       "thresholds shown. ᵃCADD scores between 10 and 20 were treated as indeterminate and excluded from default-threshold metrics. "
       "AlphaMissense and EVE are not shown because they are distributed as three-class calls (pathogenic, ambiguous/uncertain, "
       "benign); fitting a single binary threshold would discard their native indeterminate class."])

# ------------- Table 3
t3 = pd.read_csv(IN / "table3_threshold_ci.csv").set_index("tool")
ss = pd.read_csv(IN / "suggested_thresholds_summary.csv").set_index("tool")
rows = []
for t in t3.sort_values("germline_spec_change_pp_if_somatic_thr").index:
    r = t3.loc[t]
    rows.append([nm(t) + (" (PHRED)" if t == "CADD" else ""), r.germline_thr_95CI, r.somatic_thr_95CI,
                 f"{ss.loc[t, 'youden_threshold_stability_abs_diff']:g}", f"{r.abs_delta:g}",
                 f"{r.germline_spec_change_pp_if_somatic_thr:+.1f}", f"{r.germline_sens_change_pp_if_somatic_thr:+.1f}"])
table("Table 3: Threshold stability between germline- and somatic-derived MCC-maximised thresholds.",
      ["Tool", "Germline-derived threshold (95% CI)", "Somatic-derived threshold (95% CI)", "|Δ| Youden threshold",
       "|Δ| MCC-max threshold", "Change in germline specificity with somatic threshold (percentage points)",
       "Change in germline sensitivity with somatic threshold (percentage points)"], rows,
      ["|Δ| values are on each tool’s native scale and are not comparable across tools; the last two columns give a "
       "scale-free comparison. For PROVEAN and SIFT, lower scores are more damaging."])

# ------------- Table 4
rows = [["p.Arg110Leu (R110L)", "ENSP00000269305.4:p.Arg110Leu", "Pathogenic", "3/6 (0.50)", "3/6 (0.50)", "3/13 → 7/14",
         "Yes", "Independent (germline ClinVar/ClinGen VCEP vs somatic ClinVar oncogenicity)"],
        ["p.Gly262Ser (G262S)", "ENSP00000269305.4:p.Gly262Ser", "Benign", "7/7 (1.00)", "7/7 (1.00)", "15/15 → 13/15",
         "Yes", "Inherited from germline label (not independent)"]]
table("Table 4: Molecular dynamics candidate variants and their evidentiary basis.",
      ["Variant", "HGVSp", "Reference label", "Discordant / calling top-7 tools, germline", "Discordant / calling top-7 tools, somatic",
       "Discordant / calling, all 15 tools: default → recalibrated", "MaveDB functional evidence", "Label corroboration across datasets"],
      rows, ["Top-7 tools: SIFT, REVEL, ClinPred, MetaRNN, PROVEAN, AlphaMissense, EVE, at published default thresholds; "
             "indeterminate calls not counted. Recalibrated = germline-derived MCC-maximised thresholds (AlphaMissense and EVE keep "
             "native calls). Values are identical in both datasets because both variants have identical scores in each."])

# ------------- Supp Table 1: missingness (+ new tools)
gl = pd.read_csv(RAW / "germline_benchmark_final.csv"); sm = pd.read_csv(RAW / "somatic_benchmark_final_confident.csv")
pp = pd.read_csv(IN / "polyphen_myvariant.csv")[["Unified_ID", "Polyphen2_HVAR_score"]]
rows = []
miss = {d: pd.read_csv(IN / f"missingness_report_{d}.csv").set_index("tool_column") for d in ("germline", "somatic")}
show = ["SIFT_score", "REVEL_score", "CADD_score", "ClinPred_score", "MetaLR_score", "MetaRNN_score", "MetaSVM_score",
        "MVP_score", "PROVEAN_score", "DANN_score", "AlphaMissense_score", "EVE_score", "popEVE_score", "MutFormer_score",
        "MutationAssessor_score", "MutPred2_score", "MutationTaster_score", "MaveDB_score_mean"]
lab = lambda c: {"MaveDB_score_mean": "MaveDB (functional assay)", "PROVEAN_score": "PROVEAN"}.get(c, c.replace("_score", ""))
for c in show:
    g, s = miss["germline"].loc[c], miss["somatic"].loc[c]
    rows.append([lab(c), g.pct_missing, g.pct_missing_in_pathogenic, g.pct_missing_in_benign,
                 s.pct_missing, s.pct_missing_in_pathogenic, s.pct_missing_in_benign])
for d, df in (("germline", gl), ("somatic", sm)):
    df = df.merge(pp, on="Unified_ID", how="left")
    if d == "germline": gm = df
    else: smm = df
def mrow(name, gcol, scol_df_g, scol_df_s):
    out = [name]
    for df in (scol_df_g, scol_df_s):
        m = df[gcol].isna(); p = df.Binary_label == "Pathogenic"
        out += [round(100 * m.mean(), 1), round(100 * m[p].mean(), 1), round(100 * m[~p].mean(), 1)]
    return out
rows.append(mrow("PolyPhen-2 (HDIV and HVAR)", "Polyphen2_HVAR_score", gm, smm))
rows.append(mrow("BayesDel (noAF)ᵃ", "MetaLR_score", gm, smm))
table("Supplementary Table 1: Missingness by predictor (% of variants without a score).",
      ["Tool", "% missing, germline", "% missing in pathogenic (G)", "% missing in benign (G)",
       "% missing, somatic", "% missing in pathogenic (S)", "% missing in benign (S)"], rows,
      ["ᵃBayesDel was scored for the same 374 germline and 117 somatic variants as the other dbNSFP-derived tools "
       "(the 16 germline variants without a dbNSFP record); confirm against log_01 if 01 is re-run on the _v2 files."])

# ------------- Supp Table 2a/b DeLong
for d, lbl in (("germline", "2a"), ("somatic", "2b")):
    dl = pd.read_csv(IN / f"delong_pairwise_{d}.csv")
    rows = [[nm(r.tool_a), nm(r.tool_b), int(r.n_paired), f"{r.auc_a:.3f}", f"{r.auc_b:.3f}", f"{r.z:.2f}",
             f"{r.p:.2g}", f"{r.p_BH:.2g}", "Yes" if r.significant_BH else "No"] for r in dl.itertuples()]
    table(f"Supplementary Table {lbl}: Pairwise DeLong comparisons of ROC-AUC, {d} dataset (105 tool pairs).",
          ["Tool A", "Tool B", "n (scored by both)", "AUC A", "AUC B", "z", "p (nominal)", "p (BH-FDR)", "Significant after BH"], rows,
          ["Benjamini–Hochberg correction across the 105 comparisons within the dataset."])

# ------------- Supp Table 3 domain
dm = pd.read_csv(IN / "domain_stratified_ci.csv"); dd = pd.read_csv(IN / "domain_delta_auc.csv")
rows, groups = [], []
for d in ("germline", "somatic"):
    groups.append(len(rows)); rows.append([f"{d.capitalize()} dataset"])
    for t in order:
        for reg in ("DBD", "non-DBD", "ALL"):
            r = dm[(dm.tool == t) & (dm.dataset == d) & (dm.region == reg)].iloc[0]
            delta = ""
            if reg == "DBD":
                x = dd[(dd.tool == t) & (dd.dataset == d)]
                if len(x): delta = f"{x.iloc[0].delta_AUC_95CI}; BH p = {x.iloc[0].perm_p_BH:.3g}"
            rows.append([nm(t), {"ALL": "Whole gene", "DBD": "DBD (94–312)", "non-DBD": "Outside DBD"}[reg],
                         int(r.n), int(r.n_pathogenic), int(r.n_benign), r.AUC_95CI if r.AUC_95CI != "NA" else "NA (< 5 per class)", delta])
table("Supplementary Table 3: Domain-stratified performance.",
      ["Tool", "Region", "n", "n pathogenic", "n benign", "ROC-AUC (95% CI)", "ΔAUC DBD − outside (95% CI); permutation p (BH)"],
      rows, ["ΔAUC: bootstrap CI with each region resampled separately; p from 5,000 permutations of region labels, "
             "Benjamini–Hochberg-adjusted across tools. Somatic non-DBD stratum: 1 pathogenic variant, AUC not estimable."], groups)

# ------------- Supp Table 4
s4 = pd.read_csv(EXTRA)
table("Supplementary Table 4: Discrimination of additional predictors not included in the primary comparison.",
      list(s4.columns), s4.values.tolist(), ["popEVE scores are lower for more damaging variants; AUC is computed with that orientation."])

# ------------- Supp Table 5: full default-threshold metrics
rows, groups = [], []
for d in ("germline", "somatic"):
    groups.append(len(rows)); rows.append([f"{d.capitalize()} dataset"])
    b = bs[d]; sub = t1[t1.dataset == d].set_index("tool")
    for t in order:
        r = b.loc[t]
        rows.append([nm(t), num(sub.loc[t, "PRAUC_95CI"]), f"{r.ppv:.3f}", f"{r.npv:.3f}", f"{r.accuracy:.3f}",
                     f"{r.f1:.3f}", f"{r.balanced_accuracy:.3f}", f"{r.vus_rate_pct:.1f}"])
table("Supplementary Table 5: Additional performance metrics at published default thresholds.",
      ["Tool", "PR-AUC (95% CI)", "PPV", "NPV", "Accuracy", "F1", "Balanced accuracy", "% indeterminate calls"], rows, (), groups)

doc.save(OUT)
print("saved", OUT)
