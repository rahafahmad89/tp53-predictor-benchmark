"""
add_polyphen.py  -  Item 5: PolyPhen-2 HDIV and HVAR scores, from code.

Why: Ensembl's VEP (release 116) does not serve the PolyPhen-2 fields of dbNSFP ('invalid_field'),
and VEP's own PolyPhen column had no scores for residues 95-393 in your July run.
This script takes PolyPhen-2 from dbNSFP through MyVariant.info (a public dbNSFP mirror), matched by
exact genomic position and allele, then writes them into the _v2 files made by merge_new_vep_scores.py.

Needs: vep_revision_raw.json (from vep_rest_revision.py) for the genomic coordinates, and the two _v2 files.
Usage:  python3 add_polyphen.py

Writes
  polyphen_myvariant.csv      one row per variant: genomic ID, HDIV and HVAR values, how they were chosen
  polyphen_raw.json           the full MyVariant answers (keep it, commit it)
  germline_benchmark_final_v2.csv, somatic_benchmark_final_confident_v2.csv   PolyPhen columns filled in
"""
import json
import sys
import time

import numpy as np
import pandas as pd
import requests

URL = "https://myvariant.info/v1/variant"
FIELDS = "dbnsfp.polyphen2,dbnsfp.dbnsfp_version,dbnsfp.aa"


def as_list(x):
    if x is None:
        return []
    return x if isinstance(x, list) else [x]


def pick(scores, accs=None):
    """dbNSFP stores one PolyPhen-2 value per UniProt isoform. If they differ, use the most damaging
    (maximum), the same convention dbNSFP uses for its PolyPhen-2 rank scores. The choice is recorded."""
    scores = [float(s) for s in as_list(scores) if s is not None]
    if not scores:
        return np.nan, "missing"
    if len(set(scores)) == 1:
        return scores[0], "single value"
    return max(scores), "max of isoforms"


def main():
    try:
        raw = json.load(open("vep_revision_raw.json"))
    except FileNotFoundError:
        sys.exit("vep_revision_raw.json not found - run vep_rest_revision.py first.")

    rows = []
    for rec in raw:
        cpart = rec.get("input", "").split(":", 1)[-1]
        a = rec.get("allele_string", "")
        if "/" not in a:
            continue
        ref, alt = a.split("/")[:2]
        # For HGVS input VEP reports alleles on the transcript strand. TP53 is on the minus strand,
        # so convert to the genomic forward strand, which is what MyVariant.info / dbNSFP use.
        tc = next((t for t in rec.get("transcript_consequences", [])
                   if t.get("transcript_id", "").startswith("ENST00000269305")), {})
        strand = tc.get("strand", rec.get("strand", 1))
        if strand == -1:
            comp = {"A": "T", "C": "G", "G": "C", "T": "A"}
            ref, alt = comp.get(ref, ref), comp.get(alt, alt)
        gid = f"chr{rec.get('seq_region_name')}:g.{rec.get('start')}{ref}>{alt}"
        rows.append({"Unified_ID": f"NM_000546.6:{cpart}", "genomic_id": gid})
    ids = pd.DataFrame(rows).drop_duplicates("Unified_ID")
    print(f"{len(ids)} variants with genomic coordinates; querying MyVariant.info ...")

    hits, raw_out = {}, []
    q = ids["genomic_id"].tolist()
    for i in range(0, len(q), 200):
        for attempt in range(5):
            r = requests.post(URL, params={"assembly": "hg38"},
                              data={"ids": ",".join(q[i:i + 200]), "fields": FIELDS, "assembly": "hg38"},
                              timeout=180)
            if r.status_code == 200:
                break
            print(f"  HTTP {r.status_code}, retrying"); time.sleep(10)
        r.raise_for_status()
        for h in r.json():
            raw_out.append(h)
            if not h.get("notfound"):
                hits[h["query"]] = h
        time.sleep(1)
    json.dump(raw_out, open("polyphen_raw.json", "w"), indent=1)

    out, version = [], None
    for _, row in ids.iterrows():
        h = hits.get(row.genomic_id)
        db = (h or {}).get("dbnsfp", {})
        if isinstance(db, list):
            db = db[0]
        version = version or db.get("dbnsfp_version")
        pp = db.get("polyphen2", {}) or {}
        hdiv, how1 = pick((pp.get("hdiv") or {}).get("score"))
        hvar, how2 = pick((pp.get("hvar") or {}).get("score"))
        out.append({"Unified_ID": row.Unified_ID, "genomic_id": row.genomic_id,
                    "found": h is not None, "Polyphen2_HDIV_score": hdiv, "Polyphen2_HVAR_score": hvar,
                    "HDIV_choice": how1, "HVAR_choice": how2,
                    "HDIV_all_isoforms": str((pp.get("hdiv") or {}).get("score")),
                    "HVAR_all_isoforms": str((pp.get("hvar") or {}).get("score"))})
    P = pd.DataFrame(out)
    P.to_csv("polyphen_myvariant.csv", index=False)

    if not version:
        try:
            meta = requests.get("https://myvariant.info/v1/metadata", timeout=60).json()
            version = meta.get("src", {}).get("dbnsfp", {}).get("version")
        except Exception:
            pass
    print(f"dbNSFP version on MyVariant.info: {version}")
    open("polyphen_version.txt", "w").write(f"dbNSFP via MyVariant.info: {version}\nDate: {time.strftime('%Y-%m-%d')}\n")
    if P.found.sum() == 0:
        sys.exit("No variant was found. Paste me: head -3 polyphen_myvariant.csv")
    print(f"Found: {P.found.sum()}/{len(P)}; HDIV filled {P.Polyphen2_HDIV_score.notna().sum()}, "
          f"HVAR filled {P.Polyphen2_HVAR_score.notna().sum()}")
    print("How the isoform value was chosen (HDIV):", P.HDIV_choice.value_counts().to_dict())

    for f in ["germline_benchmark_final_v2.csv", "somatic_benchmark_final_confident_v2.csv"]:
        d = pd.read_csv(f)
        d = d.drop(columns=[c for c in ["Polyphen2_HDIV_score", "Polyphen2_HVAR_score"] if c in d.columns])
        d = d.merge(P[["Unified_ID", "Polyphen2_HDIV_score", "Polyphen2_HVAR_score"]], on="Unified_ID", how="left")
        d.to_csv(f, index=False)
        pos = pd.to_numeric(d["Protein_position"], errors="coerce")
        cov = d["Polyphen2_HVAR_score"].notna()
        print(f"{f}: PolyPhen-2 filled {cov.mean():.1%} | residues 1-93: {cov[pos < 94].mean():.0%}, "
              f"94-312: {cov[pos.between(94, 312)].mean():.0%}, 313-393: {cov[pos > 312].mean():.0%}")
    print("\nNext: bash run_revision.sh")


if __name__ == "__main__":
    main()
