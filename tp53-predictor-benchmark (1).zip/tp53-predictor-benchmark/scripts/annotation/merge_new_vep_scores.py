"""
merge_new_vep_scores.py  -  Revision item 5 (and the item 1 cross-check).

Takes the NEW VEP output for the 390 benchmark variants and adds ONLY the new score columns to your
existing benchmark files. Nothing else in your data changes: same variants, same labels, same scores
for the 12 original tools.

Input
  vep_revision.txt                         the new VEP web output (tab-delimited .txt)
  germline_benchmark_final.csv             unchanged
  somatic_benchmark_final_confident.csv    unchanged
Output
  germline_benchmark_final_v2.csv
  somatic_benchmark_final_confident_v2.csv
  (= the original files plus Polyphen2_HDIV_score, Polyphen2_HVAR_score, BayesDel_noAF_score,
     and MetaSVM_score_newVEP for the item 1 cross-check)

Usage:  python3 merge_new_vep_scores.py vep_revision.txt

The same canonical-transcript filter and Unified_ID rule as clean_vep.py / extract_predictors.py are
used, so rows match one to one.
"""
import sys

import numpy as np
import pandas as pd

CANONICAL_UNIPROT = "P04637"
NEW = {  # output column : VEP/dbNSFP column
    "Polyphen2_HDIV_score": "Polyphen2_HDIV_score",
    "Polyphen2_HVAR_score": "Polyphen2_HVAR_score",
    "BayesDel_noAF_score": "BayesDel_noAF_score",
    "MetaSVM_score_newVEP": "MetaSVM_score",
}
ISOFORM_COLS = ["Uniprot_acc_Polyphen2", "Uniprot_acc"]   # used to pick P04637 when PolyPhen has several values


def split(v):
    if pd.isna(v) or v in ("-", ""):
        return []
    return [p.strip() for p in str(v).replace("&", ",").split(",")]


BAD = {}   # column -> set of non-numeric tokens the API returned (e.g. 'invalid_field')


def to_float(x):
    try:
        return float(x)
    except ValueError:
        return None


def pick(value, accs, notes, vid, col):
    vals = split(value)
    for x in vals:
        if x not in (".", "") and to_float(x) is None:
            BAD.setdefault(col, set()).add(x)
    vals = [x if to_float(x) is not None else "." for x in vals]
    nums = [float(x) for x in vals if x not in (".", "")]
    if not nums:
        return np.nan
    if len(set(nums)) == 1:
        return nums[0]
    if accs and len(accs) == len(vals):
        for v, a in zip(vals, accs):
            if a == CANONICAL_UNIPROT and v not in (".", ""):
                return float(v)
    notes.append((vid, col, value))
    return np.nan


def main(vep_path):
    vep = pd.read_csv(vep_path, sep="\t", dtype=str, encoding="utf-8")
    vep = vep[(vep["CANONICAL"] == "YES") & (~vep["Feature"].str.startswith("NM_"))]
    vep = vep[vep["Consequence"].str.contains("missense_variant")].copy()

    def build_id(row):   # identical to extract_predictors.py
        mane, hgvsc = row["MANE_SELECT"], row["HGVSc"]
        if pd.isna(mane) or mane == "-" or pd.isna(hgvsc) or hgvsc == "-":
            return row["#Uploaded_variation"]
        return f"{mane}:{hgvsc.split(':', 1)[1] if ':' in hgvsc else hgvsc}"

    vep["Unified_ID"] = vep.apply(build_id, axis=1)
    vep = vep.drop_duplicates("Unified_ID")
    missing_cols = [c for c in NEW.values() if c not in vep.columns]
    if missing_cols:
        sys.exit(f"These columns are not in the VEP file: {missing_cols}\n"
                 f"Re-run VEP and tick them in the dbNSFP field list.")
    iso_col = next((c for c in ISOFORM_COLS if c in vep.columns), None)
    notes = []
    new = pd.DataFrame({"Unified_ID": vep["Unified_ID"].values})
    for out_col, vcol in NEW.items():
        new[out_col] = [pick(v, split(a) if iso_col else None, notes, vid, out_col)
                        for v, a, vid in zip(vep[vcol], vep[iso_col] if iso_col else [None] * len(vep),
                                             vep["Unified_ID"])]

    if BAD:
        print("\nNon-numeric values returned by VEP (treated as missing):")
        for c, toks in BAD.items():
            print(f"  {c}: {sorted(toks)}")
        if any("invalid_field" in t for t in BAD.values()):
            print("  'invalid_field' means this VEP release's dbNSFP has no field with that exact name.")

    for src, dst in [("germline_benchmark_final.csv", "germline_benchmark_final_v2.csv"),
                     ("somatic_benchmark_final_confident.csv", "somatic_benchmark_final_confident_v2.csv")]:
        old = pd.read_csv(src)
        merged = old.merge(new, on="Unified_ID", how="left")
        assert len(merged) == len(old), "row count changed - duplicate Unified_ID in VEP output"
        merged.to_csv(dst, index=False)
        print(f"\n{dst}: {len(merged)} rows (same as {src})")
        pos = pd.to_numeric(merged["Protein_position"], errors="coerce")
        for c in NEW:
            cov = merged[c].notna()
            print(f"  {c:24s} {cov.mean():6.1%} filled | residues 1-93: {cov[pos < 94].mean():.0%}, "
                  f"94-312: {cov[pos.between(94, 312)].mean():.0%}, 313-393: {cov[pos > 312].mean():.0%}")
        unmatched = merged["MetaSVM_score_newVEP"].isna() & merged["MetaSVM_score"].notna()
        if unmatched.any():
            print(f"  WARNING: {int(unmatched.sum())} variants not found in the new VEP file")

    if notes:
        pd.DataFrame(notes, columns=["Unified_ID", "column", "raw_value"]).to_csv("isoform_ambiguous_values.csv", index=False)
        print(f"\n{len(notes)} values had several different isoform scores and no UniProt column to resolve "
              f"them; they were left empty and listed in isoform_ambiguous_values.csv. "
              f"Re-run VEP with Uniprot_acc ticked to resolve them.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Usage: python3 merge_new_vep_scores.py <new VEP output .txt>")
    main(sys.argv[1])
