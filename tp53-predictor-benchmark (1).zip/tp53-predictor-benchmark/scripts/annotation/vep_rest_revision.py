"""
vep_rest_revision.py  -  Revision item 5: run VEP from code (Ensembl REST API), no web form, no downloads.

Annotates the 390 benchmark variants in tp53_revision_vep_input.txt with the dbNSFP fields the
revision needs, and writes vep_revision.txt in the same tab format as the VEP web output, so the
next step is unchanged:  python3 merge_new_vep_scores.py vep_revision.txt

Usage (inside "data benchmarking"):
    pip install requests
    python3 vep_rest_revision.py

Writes
    vep_revision.txt           one row per variant, canonical transcript ENST00000269305
    vep_revision_raw.json      the full API responses (keep it: it is your record of what VEP returned)
    vep_revision_versions.txt  Ensembl release and API version used (for Methods, item 29)

Notes
  * Variants are sent as ENST00000269305:c.XXX (the Ensembl ID of MANE Select NM_000546.6; same c. numbering).
  * The API accepts at most 200 variants per request, so 390 variants = 2 requests (~1 minute).
  * If the API is busy (HTTP 429/503) the script waits and retries automatically.
"""
import json
import sys
import time

import requests

SERVER = "https://rest.ensembl.org"
INPUT = "tp53_revision_vep_input.txt"
CANONICAL = "ENST00000269305"
MANE = "NM_000546.6"
FIELDS = ["Polyphen2_HDIV_score", "Polyphen2_HVAR_score", "BayesDel_noAF_score",
          "MetaSVM_score", "MetaSVM_pred", "Uniprot_acc"]
BATCH = 200
HEADERS = {"Content-Type": "application/json", "Accept": "application/json"}


def post(batch):
    body = {"hgvs_notations": batch, "dbNSFP": ",".join(FIELDS),
            "canonical": 1, "mane": 1, "hgvs": 1, "uniprot": 1}
    for attempt in range(8):
        r = requests.post(f"{SERVER}/vep/human/hgvs", headers=HEADERS, data=json.dumps(body), timeout=300)
        if r.status_code == 200:
            return r.json()
        if r.status_code in (429, 502, 503, 504):
            wait = float(r.headers.get("Retry-After", 10 * (attempt + 1)))
            print(f"  server busy ({r.status_code}), retrying in {wait:.0f} s")
            time.sleep(wait)
            continue
        sys.exit(f"VEP REST error {r.status_code}: {r.text[:500]}")
    sys.exit("VEP REST did not respond after 8 attempts; try again later.")


def get_field(tc, name):
    """dbNSFP keys come back lower-cased in JSON; match case-insensitively."""
    for k, v in tc.items():
        if k.lower() == name.lower():
            if isinstance(v, list):
                return ",".join(str(x) for x in v)
            return str(v)
    return "-"


def main():
    ids = [l.strip() for l in open(INPUT) if l.strip()]
    # NM_000546.6:c.784G>A  ->  ENST00000269305:c.784G>A
    query = {f"{CANONICAL}:{i.split(':', 1)[1]}": i for i in ids}
    print(f"{len(ids)} variants -> {(len(ids) + BATCH - 1) // BATCH} requests")

    results, raw = {}, []
    keys = list(query)
    for k in range(0, len(keys), BATCH):
        batch = keys[k:k + BATCH]
        print(f"  request {k // BATCH + 1}: {len(batch)} variants")
        resp = post(batch)
        raw.extend(resp)
        for rec in resp:
            results[rec.get("input") or rec.get("id")] = rec
        time.sleep(1)
    json.dump(raw, open("vep_revision_raw.json", "w"), indent=1)

    # show what the API returned for one variant, so field names can be checked
    first = next((tc for rec in raw for tc in rec.get("transcript_consequences", [])
                  if tc.get("transcript_id", "").startswith(CANONICAL)), None)
    if first:
        print("\nFields returned for the canonical transcript (first variant):")
        print("  " + ", ".join(sorted(first.keys())))

    cols = ["#Uploaded_variation", "Feature", "CANONICAL", "Consequence", "MANE_SELECT", "HGVSc"] + FIELDS
    lines, missing = ["\t".join(cols)], []
    for q, unified in query.items():
        rec = results.get(q)
        tc = None
        if rec:
            tc = next((t for t in rec.get("transcript_consequences", [])
                       if t.get("transcript_id", "").startswith(CANONICAL)), None)
        if tc is None:
            missing.append(unified)
            continue
        row = [unified, tc.get("transcript_id", CANONICAL), "YES",
               ",".join(tc.get("consequence_terms", [])), MANE, f"{tc.get('transcript_id', CANONICAL)}:{unified.split(':', 1)[1]}"]
        row += [get_field(tc, f) for f in FIELDS]
        lines.append("\t".join(row))
    open("vep_revision.txt", "w").write("\n".join(lines) + "\n")

    try:
        sw = requests.get(f"{SERVER}/info/software", headers=HEADERS, timeout=60).json()
        rest = requests.get(f"{SERVER}/info/rest", headers=HEADERS, timeout=60).json()
        info = f"Ensembl release: {sw.get('release')}\nREST API version: {rest.get('release')}\nDate: {time.strftime('%Y-%m-%d')}\n"
    except Exception as e:
        info = f"Could not fetch version info: {e}\n"
    open("vep_revision_versions.txt", "w").write(info)

    print(f"\nSaved vep_revision.txt: {len(lines) - 1} of {len(ids)} variants")
    print(info.strip())
    filled, invalid = {}, {}
    for i, f in enumerate(FIELDS):
        vals = [l.split("\t")[6 + i] for l in lines[1:]]
        invalid[f] = sum("invalid_field" in v for v in vals)
        filled[f] = sum(v not in ("-", "", "None") and "invalid_field" not in v for v in vals)
    for f in FIELDS:
        note = f"   <-- 'invalid_field' in {invalid[f]} rows: name not in this dbNSFP version" if invalid[f] else ""
        print(f"  {f:22s} filled for {filled[f]}/{len(lines) - 1}{note}")
    if missing:
        open("vep_revision_missing.txt", "w").write("\n".join(missing) + "\n")
        print(f"WARNING: {len(missing)} variants had no canonical-transcript result -> vep_revision_missing.txt")
    if all(n == 0 for n in filled.values()):
        print("\nNo dbNSFP values came back. Send me the 'Fields returned' line above and vep_revision_raw.json.")
    print("\nNext: python3 merge_new_vep_scores.py vep_revision.txt")


if __name__ == "__main__":
    main()
