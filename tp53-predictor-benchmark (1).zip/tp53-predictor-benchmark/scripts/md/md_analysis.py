import sys, glob, os, numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
D = sys.argv[1]; OUT = sys.argv[2]; os.makedirs(OUT, exist_ok=True)
def xvg(f):
    return np.loadtxt([l for l in open(f) if not l.startswith(('#','@'))])
SYS = {"WT": "", "R110L": "R110L_", "G262S": "G262S_"}
LIG = ["Cys176", "His179", "Cys238", "Cys242"]
rows, rmsf = [], {}
for s, p in SYS.items():
    rmsf[s] = []
    for r in (1,2,3):
        a = xvg(f"{D}/rmsd_{p}rep{r}.xvg"); t, y = a[:,0], a[:,1]*10
        h = t >= t.max()/2
        sl = stats.linregress(t[h], y[h])
        q = len(y)//4; blocks = [y[i*q:(i+1)*q].mean() for i in range(4)]
        rows.append(dict(system=s, rep=r, mean_RMSD_last2ns_A=y[h].mean(), sd=y[h].std(ddof=1),
                         slope_last2ns_A_per_ns=sl.slope, slope_p=sl.pvalue,
                         block3_A=blocks[2], block4_A=blocks[3], drift_b3_b4_A=blocks[3]-blocks[2],
                         plateau=abs(sl.slope) < 0.1))
        f = xvg(f"{D}/rmsf_{p}rep{r}.xvg"); rmsf[s].append(f[:,1]*10); res = f[:,0].astype(int)
R = pd.DataFrame(rows); R.to_csv(f"{OUT}/md_rmsd_plateau.csv", index=False)
print(R.round(3).to_string()); print("plateau count:", R.plateau.sum(), "/ 9")
out = []
for m in ["R110L", "G262S"]:
    W, M = np.array(rmsf["WT"]), np.array(rmsf[m])
    pw = stats.ttest_ind(M, W, axis=0, equal_var=False).pvalue
    ps = stats.ttest_ind(M, W, axis=0, equal_var=True).pvalue
    bh_w = multipletests(pw, method="fdr_bh")[1]; bh_s = multipletests(ps, method="fdr_bh")[1]
    for i, rr in enumerate(res):
        out.append(dict(mutant=m, residue=rr, WT_mean_A=W[:,i].mean(), WT_sd=W[:,i].std(ddof=1),
                        mut_mean_A=M[:,i].mean(), mut_sd=M[:,i].std(ddof=1),
                        p_welch=pw[i], p_BH_welch=bh_w[i], p_student=ps[i], p_BH_student=bh_s[i]))
T = pd.DataFrame(out); T.to_csv(f"{OUT}/md_rmsf_residue_tests.csv", index=False)
for m in ["R110L","G262S"]:
    t = T[T.mutant==m]
    print(f"\n{m}: min BH welch {t.p_BH_welch.min():.3g}, min BH student {t.p_BH_student.min():.3g}; "
          f"nominal welch<0.05: {(t.p_welch<0.05).sum()}, student<0.05: {(t.p_student<0.05).sum()}")
    print(t[t.residue.isin([110,185,210,262])].round(4).to_string())
    print(t.nsmallest(5,"p_student")[["residue","WT_mean_A","mut_mean_A","p_welch","p_student","p_BH_student"]].round(4).to_string())
# whole-protein mean RMSF per replicate
G = []
for s in SYS: 
    for r,v in enumerate(rmsf[s],1): G.append(dict(system=s, rep=r, mean_RMSF_A=v.mean()))
G = pd.DataFrame(G); G.to_csv(f"{OUT}/md_mean_rmsf.csv", index=False); print(G.groupby("system").mean_RMSF_A.agg(['mean','std']).round(3))
Z = []
for s, p in SYS.items():
    for L in LIG:
        for r in (1,2,3):
            f = f"{D}/zndist_{p}rep{r}_{L}.xvg" if s!="WT" else (f"{D}/zn_dist_rep{r}.xvg" if L=="Cys176" else None)
            if not f or not os.path.exists(f): continue
            y = xvg(f)[:,1]*10
            Z.append(dict(system=s, ligand=L, rep=r, mean_A=y.mean(), sd_A=y.std(ddof=1), max_A=y.max()))
Z = pd.DataFrame(Z); Z.to_csv(f"{OUT}/md_zn_distances.csv", index=False)
print(Z.groupby(["system","ligand"]).agg(mean=("mean_A","mean"), sd_between=("mean_A","std"),
      within_sd=("sd_A","mean"), max=("max_A","max")).round(3))
for s in ["WT","R110L","G262S"]:
    print(s, "RMSD last-half mean of reps: %.2f ± %.2f" % (R[R.system==s].mean_RMSD_last2ns_A.mean(), R[R.system==s].mean_RMSD_last2ns_A.std()))
