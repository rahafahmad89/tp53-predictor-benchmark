"""Figure 5A-C from the Colab qc_analysis .xvg files. Usage: python3 make_figure5.py <qc_analysis dir> <out dir>
WT Zn distances: zn_dist_rep{r}.xvg = Cys176; extra WT ligands are used if zndist_WT_rep{r}_{ligand}.xvg exist."""
import sys, os, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
D, OUT = sys.argv[1], sys.argv[2]; os.makedirs(OUT, exist_ok=True)
def x(f): return np.loadtxt([l for l in open(f) if not l.startswith(('#', '@'))])
SYS = {"WT": "", "R110L": "R110L_", "G262S": "G262S_"}
COL = {"WT": "#555555", "R110L": "#2166ac", "G262S": "#b2182b"}
LIG = ["Cys176", "His179", "Cys238", "Cys242"]
REST = {"Cys176": (2.03, 2.63), "His179": (1.76, 2.36), "Cys238": (1.91, 2.51), "Cys242": (1.94, 2.54)}  # flat-bottom, Å
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": "#444444", "axes.linewidth": 0.8,
                     "xtick.color": "#444444", "ytick.color": "#444444", "axes.labelcolor": "#222222"})
NOD = "--no-d" in sys.argv
if NOD:
    fig = plt.figure(figsize=(7.2, 7.6)); gs = fig.add_gridspec(3, 3, height_ratios=[0.8, 1, 0.9], hspace=0.55)
    axA, axB, axC = fig.add_subplot(gs[0, :]), fig.add_subplot(gs[1, :]), fig.add_subplot(gs[2, 0:2])
else:
    fig = plt.figure(figsize=(7.2, 8.8)); gs = fig.add_gridspec(3, 2, height_ratios=[0.8, 1, 1.05], hspace=0.62, wspace=0.3)
    axA, axB, axC = fig.add_subplot(gs[0, :]), fig.add_subplot(gs[1, :]), fig.add_subplot(gs[2, 0])
# right half of row 3 is left empty for panel D (ChimeraX image)
def clean(ax):
    ax.spines[["top", "right"]].set_visible(False); ax.grid(axis="y", color="#e6e6e6", lw=0.6); ax.set_axisbelow(True)
# A RMSD
for s, p in SYS.items():
    for r in (1, 2, 3):
        a = x(f"{D}/rmsd_{p}rep{r}.xvg")
        axA.plot(a[:, 0], a[:, 1] * 10, color=COL[s], lw=0.7, alpha=0.85, label=s if r == 1 else None)
axA.set_xlabel("Time (ns)"); axA.set_ylabel("Backbone RMSD (Å)"); axA.set_xlim(0, 4); axA.set_ylim(0, None)
axA.legend(fontsize=8, frameon=False, loc="lower right", ncol=3); clean(axA)
axA.set_title("A", loc="left", fontsize=11, fontweight="bold")
# B RMSF
for s, p in SYS.items():
    M = np.array([x(f"{D}/rmsf_{p}rep{r}.xvg")[:, 1] * 10 for r in (1, 2, 3)])
    res = x(f"{D}/rmsf_{p}rep1.xvg")[:, 0]; m, sd = M.mean(0), M.std(0, ddof=1)
    axB.fill_between(res, m - sd, m + sd, color=COL[s], alpha=0.15, lw=0); axB.plot(res, m, color=COL[s], lw=1, label=s)
for z in (176, 179, 238, 242): axB.axvline(z, color="#bbbbbb", lw=0.6, ls=":")
axB.axvline(185, color="#b2182b", lw=0.8, ls="--")
axB.text(186, axB.get_ylim()[1] * 0.97, "185", color="#b2182b", fontsize=8, va="top")
axB.text(179, axB.get_ylim()[1] * 0.97, "Zn ligands ", color="#888888", fontsize=7, va="top", ha="right")
axB.set_xlabel("Residue"); axB.set_ylabel("Backbone RMSF (Å)"); axB.set_xlim(res.min(), res.max())
axB.legend(fontsize=8, frameon=False, ncol=3, loc="upper right"); clean(axB)
axB.set_title("B", loc="left", fontsize=11, fontweight="bold")
# C Zn distances
w = 0.26
for i, L in enumerate(LIG):
    lo, hi = REST[L]; axC.add_patch(plt.Rectangle((i - 0.45, lo), 0.9, hi - lo, color="#eeeeee", lw=0, zorder=0))
    for j, (s, p) in enumerate(SYS.items()):
        vals = []
        for r in (1, 2, 3):
            f = (f"{D}/zn_dist_rep{r}.xvg" if L == "Cys176" else f"{D}/zndist_WT_rep{r}_{L}.xvg") if s == "WT" \
                else f"{D}/zndist_{p}rep{r}_{L}.xvg"
            if os.path.exists(f): vals.append((x(f)[:, 1] * 10).mean())
        xi = i + (j - 1) * w
        if vals:
            axC.errorbar(xi, np.mean(vals), yerr=np.std(vals, ddof=1) if len(vals) > 1 else None, fmt="o", ms=4.5,
                         color=COL[s], capsize=2, lw=0.8, label=s if i == 0 else None, zorder=2)
        else:
            axC.text(xi, 1.88, "n/c", ha="center", fontsize=6, color="#888888", rotation=90)
axC.axhline(2.3, color="#888888", lw=0.7, ls="--"); axC.text(3.45, 2.31, "typical Zn–S", fontsize=7, color="#777777", ha="right", va="bottom")
axC.set_xticks(range(4)); axC.set_xticklabels(LIG, fontsize=8); axC.set_ylim(1.7, 2.95); axC.set_ylabel("Zn–ligand distance (Å)")
axC.legend(fontsize=7.5, frameon=False, ncol=3, loc="upper center", handletextpad=0.2, columnspacing=0.8); clean(axC)
axC.set_title("C", loc="left", fontsize=11, fontweight="bold")
if "--strip" in sys.argv and not NOD:
    from matplotlib.colors import LinearSegmentedColormap
    cm = LinearSegmentedColormap.from_list("d", ["#2166ac", "#f7f7f7", "#b2182b"])
    sub = gs[2, 1].subgridspec(2, 1, height_ratios=[1, 0.09], hspace=0.9)
    axD, cax = fig.add_subplot(sub[0]), fig.add_subplot(sub[1])
    Mw = np.mean([x(f"{D}/rmsf_rep{r}.xvg")[:, 1] * 10 for r in (1, 2, 3)], 0)
    rows = [np.mean([x(f"{D}/rmsf_{m}_rep{r}.xvg")[:, 1] * 10 for r in (1, 2, 3)], 0) - Mw for m in ("G262S", "R110L")]
    res = x(f"{D}/rmsf_rep1.xvg")[:, 0]
    im = axD.imshow(np.array(rows), aspect="auto", cmap=cm, vmin=-1.2, vmax=1.2, interpolation="nearest",
                    extent=[res.min() - 0.5, res.max() + 0.5, 1.5, -0.5])
    axD.set_yticks([0, 1]); axD.set_yticklabels(["G262S − WT", "R110L − WT"], fontsize=8)
    axD.tick_params(axis="y", length=0)
    for lab, a, b in (("L1", 112, 124), ("L2", 164, 194), ("L3", 237, 250)):
        axD.plot([a, b], [-0.75, -0.75], color="#444444", lw=1.2, clip_on=False)
        axD.text((a + b) / 2, -0.85, lab, ha="center", va="bottom", fontsize=7.5, color="#444444")
    for z in (176, 179, 238, 242):
        axD.plot([z, z], [1.55, 1.85], color="#888888", lw=0.8, clip_on=False)
    axD.text(208, 1.72, "Zn ligands", fontsize=6.5, color="#888888", va="center", ha="center")
    for r_, lab in ((185, "185"), (262, "262")):
        axD.annotate(lab, (r_, -0.5), xytext=(r_, -1.35), ha="center", fontsize=7.5, color="#b2182b",
                     arrowprops=dict(arrowstyle="-", color="#b2182b", lw=0.8), annotation_clip=False)
    axD.set_xlabel("Residue", labelpad=10); axD.set_xlim(res.min() - 0.5, res.max() + 0.5)
    for sp in axD.spines.values(): sp.set_visible(False)
    cb = fig.colorbar(im, cax=cax, orientation="horizontal"); cb.set_label("ΔRMSF vs WT (Å)", fontsize=8)
    cb.ax.tick_params(labelsize=7); cb.outline.set_linewidth(0.5)
    axD.set_title("D", loc="left", fontsize=11, fontweight="bold", pad=22)
    NOD = "_strip"
for ext in ("png", "pdf"): fig.savefig(f"{OUT}/Figure5_ABC_MD{NOD if isinstance(NOD, str) else ('_noD' if NOD else '')}.{ext}", dpi=600, bbox_inches="tight")
for nm, ax in (("A", axA), ("B", axB), ("C", axC)):   # single panels, for assembling with panel D
    bb = ax.get_tightbbox(fig.canvas.get_renderer()).transformed(fig.dpi_scale_trans.inverted()).padded(0.05)
    fig.savefig(f"{OUT}/Figure5{nm}.png", dpi=600, bbox_inches=bb)
print("saved")
