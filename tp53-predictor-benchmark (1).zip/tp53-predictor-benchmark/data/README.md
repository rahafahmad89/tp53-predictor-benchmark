# Data

- `germline_benchmark_final.csv` (390 variants) and `somatic_benchmark_final_confident.csv` (117): processed datasets as first annotated.
- `*_v2.csv`: the same variants with BayesDel and PolyPhen-2 added (used by the pipeline from step 02 on).
- Key columns: `Unified_ID` (NM_000546.6 HGVS), `HGVSp`, `Protein_position`, `<tool>_score` / `<tool>_pred`, `Binary_label` (Pathogenic/Benign reference label), `Label_source` / `Label_source_final`.
- `annotation/`: VEP input lists, version records (`vep_revision_versions.txt`, `polyphen_version.txt`), PolyPhen-2 values with all isoform scores (`polyphen_myvariant.csv`).
- `md/qc_analysis/`: GROMACS outputs. WT files have no system prefix (`rmsd_rep1.xvg`); mutants are `rmsd_G262S_rep1.xvg` etc. `zn_dist_rep*.xvg` (WT) is the Zn–Cys176 distance only.
